/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_ACCESS_REGISTER_H__
#define __SXD_ACCESS_REGISTER_H__

#include <complib/sx_log.h>
#include <sx/sxd/sxd_emad.h>
#include <sx/sxd/sxd_emad_acl.h>
#include <sx/sxd/sxd_emad_cos.h>
#include <sx/sxd/sxd_emad_fdb.h>
#include <sx/sxd/sxd_emad_flow_counter.h>
#include <sx/sxd/sxd_emad_host.h>
#include <sx/sxd/sxd_emad_lag.h>
#include <sx/sxd/sxd_emad_mstp.h>
#include <sx/sxd/sxd_emad_policer.h>
#include <sx/sxd/sxd_emad_port.h>
#include <sx/sxd/sxd_emad_mpls.h>
#include <sx/sxd/sxd_emad_redecn.h>
#include <sx/sxd/sxd_emad_router.h>
#include <sx/sxd/sxd_emad_shspm.h>
#include <sx/sxd/sxd_emad_system.h>
#include <sx/sxd/sxd_emad_vlan.h>
#include <sx/sxd/sxd_emad_span.h>
#include <sx/sxd/sxd_emad_tunnel.h>
#include <sx/sxd/sxd_emad_rm.h>
#include <sx/sxd/sxd_emad_common_data.h>
#include <sx/sxd/kernel_user.h>
#include <sx/sxd/sxd_command_ifc.h>
#include <sx/sxd/sxd_access_register_init.h>


/************************************************
 *  Local Defines
 ***********************************************/


/**
 * MAX_REGISTERS_TO_ACCESS defines the maximum
 * number of register accesses possible in a single API call.
 */
#define MAX_REGISTERS_TO_ACCESS     100
#define MTBR_MAX_TEMPERATURE_RECORD 7

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/


/**
 * sxd_access_reg_hw_t structure is used to store general
 * access_reg library data.
 */
typedef struct sxd_access_reg_hw {
    sxd_command_ifc_hw_t *cmd_ifc_hw_p;
    struct ibmad_port    *sport;
    cl_spinlock_t         mtx; /*!< mutex lock on parallel MAD sends of multiple threads */
} sxd_access_reg_hw_t;

/**
 * sxd_reg_meta structure is used to store access register meta data.
 */
typedef struct sxd_reg_meta {
    sxd_access_cmd_t  access_cmd; /**< access_cmd - The required access command */
    sxd_dev_id_t      dev_id; /**< dev_id - The ID of the device to access */
    sxd_swid_t        swid; /**< swid - The ID of the switch through which the device is accessed */
    sxd_access_mode_t mode;
} sxd_reg_meta_t;

typedef void (*sxd_completion_handler_t) (void *context);

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/* Do not move this include.
 *  It includes auto generated code which uses structures defined above */
#include <sx/sxd/auto_registers/sxd_access_register_auto.h>

/**
 *  This function sets the lag operating state
 *
 * @param[in] lag_id            - the LAG ID.
 * @param[in] oper_state        - LAG operating state.
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_lag_oper_state_set(uint16_t lag_id,
                                               uint8_t  oper_state);

/**
 *  This function sets port BER monitor state
 *
 * @param[in] local_port        - Local port.
 * @param[in] ber_monitor_state - BER monitor state.
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_port_ber_monitor_state_set(uint16_t local_port,
                                                       uint8_t  ber_monitor_state);

/**
 *  This function sets port BER monitor bitmask
 *
 * @param[in] local_port        - Local port.
 * @param[in] bitmask           - BER monitor bitmask.
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_port_ber_monitor_bitmask_set(uint16_t local_port,
                                                         uint8_t  bitmask);

/**
 *  This function sets telemetry threshold configuration.
 *
 * @param[in] local_port        - Local port.
 * @param[in] dir_ing           - Direction Egress / Ingress.
 * @param[in] tc_vec            - Enabled TCs.
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_tele_threshold_set(uint8_t  local_port,
                                               uint8_t  dir_ing,
                                               uint64_t tc_vec);

/**
 *  This function sets the default vid of a port or a lag
 *
 * @param[in] dev_id            - the device ID.
 * @param[in] is_lag            - is it a lag.
 * @param[in] sysport           - the system port.
 * @param[in] lag_id            - the LAG ID.
 * @param[in] default_vid       - the default vid.
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_set_default_vid(sxd_dev_id_t      dev_id,
                                            uint8_t           is_lag,
                                            sxd_port_sys_id_t sysport,
                                            uint16_t          lag_id,
                                            sxd_vid_t         default_vid);

#ifdef SW_PUDE_EMULATION /* PUDE WA for NOS (PUDE events are handled by SDK). Needed for BU. */
/**
 *  This function sets the admin status of the port
 *
 * @param[in] dev_id       - the device ID.
 * @param[in] sysport      - the system port.
 * @param[in] admin_status - the admin status of the port.
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_set_admin_status(sxd_dev_id_t            dev_id,
                                             sxd_port_sys_id_t       sysport,
                                             sxd_paos_admin_status_t admin_status);
#endif /* SW_PUDE_EMULATION */

/**
 *  This function sets the vid membership of a port or a lag
 *
 * @param[in] dev_id        - the device ID.
 * @param[in] is_lag        - is it a lag.
 * @param[in] sysport       - the system port.
 * @param[in] lag_id        - the LAG ID.
 * @param[in] vid           - the default vid.
 * @param[in] is_tagged     - is tagged .
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_set_vid_membership(sxd_dev_id_t      dev_id,
                                               uint8_t           is_lag,
                                               sxd_port_phy_id_t phy_port,
                                               uint16_t          lag_id,
                                               sxd_vid_t         vid,
                                               uint8_t           is_tagged);

/**
 *  This function sets the prio tagging mode of a port or a lag
 *
 * @param[in] dev_id        - the device ID.
 * @param[in] is_lag        - is it a lag.
 * @param[in] sysport       - the system port.
 * @param[in] lag_id        - the LAG ID.
 * @param[in] is_prio_tagged   - is port prio tagged.
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_set_prio_tagging(sxd_dev_id_t      dev_id,
                                             uint8_t           is_lag,
                                             sxd_port_phy_id_t phy_port,
                                             uint16_t          lag_id,
                                             uint8_t           is_prio_tagged);

/**
 *  This function sets the prio to tc mapping of a port or a lag
 *
 * @param[in] dev_id        - the device ID.
 * @param[in] is_lag        - is it a lag.
 * @param[in] sysport       - the system port.
 * @param[in] lag_id        - the LAG ID.
 * @param[in] prio_to_tc_map   - prio to tc mapping .
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_set_prio_to_tc(sxd_dev_id_t            dev_id,
                                           uint8_t                 is_lag,
                                           sxd_port_phy_id_t       phy_port,
                                           uint16_t                lag_id,
                                           sxd_cos_port_priority_t priority,
                                           sxd_cos_traffic_class_t traffic_class);

/**
 *  This function performs ISSU FW.
 *
 * @param[in] dev_id - Device ID.
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_issu_fw(sxd_dev_id_t dev_id);

/**
 *  This function retrieve the value of the resource ID
 *
 * @param[out] rsrc_p - resource information.
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_query_rsrc_info(struct ku_query_rsrc *rsrc_p);

/**
 *  This function retrieve various firmware properties
 *
 * @param[out] fw_info_p - firmware information.
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_query_fw_info(query_fw_t *fw_info_p);

/**
 *  This function sets MAD demux
 *
 * @param[in] dev_id - device ID to set the MAD demux on.
 * @param[in] enable - 1: enable, 0: disable
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_set_mad_demux(sxd_dev_id_t dev_id, uint8_t enable);

/**
 *  This function sets IB node description only in driver
 *
 * @param[in] node_desc - IB node description info
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_set_sw_ib_node_description(struct ku_ib_node_description *node_desc);

/**
 *  This function retrieve board information
 *
 * @param[out] board_info_p - board information.
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_query_board_info(struct ku_query_board_info *board_info_p);

/**
 *  The SW_RATE_LIMITER_SET command sets a SW rate limiter on a RDQ.
 *
 * @param[in,out] rate_limiter_params   - rate limiter params
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_access_reg_sw_rate_limiter_set(struct ku_set_rdq_rate_limiter *rate_limiter_params);

/**
 *  The TRUNCATE_SIZE_SET command sets the truncate parameters of an RDQ.
 *
 * @param[in,out] truncate_params   - truncate parameters
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_access_reg_truncate_size_set(struct ku_set_truncate_params *truncate_params);

/**
 *  The GET_PCI_PROFILE command gets the pci profile from the driver.
 *
 * @param[out] pci_profile_p   - pci profile from the driver
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_access_reg_pci_profile_get(struct sx_pci_profile *pci_profile_p);

/**
 *  The CONFIG_PROFILE command sets and queries the Switch Profile.
 *  The set command can be executed on the device only once at
 *  startup in order to allocate and configure all switch resources
 *  and prepare it for operational mode.
 *  It is not possible to change the device profile after the chip is
 *  in operational mode.
 *
 * @param[in]     access_cmd   - GET / SET
 * @param[in,out] profile_p    - device profile
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_device_profile_access(sxd_access_cmd_t   access_cmd,
                                                  struct ku_profile *profile_p);

/**
 *  This function saves the sx_core driver DB to parameter sx_core_db_p.
 *
 * @param[out] sx_core_db_p  - sx_core driver DB
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_access_reg_sx_core_db_save(struct ku_sx_core_db *sx_core_db_p);

/**
 *  This function checks whether restoring the sx_core driver DB is allowed or not.
 *
 * @param[out] is_restore_allowed_p  - is it allowed to restore sx_core driver DB
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_access_reg_sx_core_db_restore_allowed(sxd_boolean_t *is_restore_allowed_p);

/**
 *  This function restores the sx_core driver DB from parameter sx_core_db_p.
 *
 * @param[in] sx_core_db_p  - sx_core driver DB
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_access_reg_sx_core_db_restore(struct ku_sx_core_db *sx_core_db_p);

/**
 *  This function performs access register PTYS operations.
 *
 * @param[in] ptys_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ptys(struct ku_ptys_reg      *ptys_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MHSR operations.
 *
 * @param[in] mhsr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mhsr(struct ku_mhsr_reg      *mhsr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);


/**
 *  This function performs access register PMTU operations.
 *
 * @param[in] pmtu_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pmtu(struct ku_pmtu_reg      *pmtu_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PPLR operations.
 *
 * @param[in] pplr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pplr(struct ku_pplr_reg      *pplr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PVLC operations.
 *
 * @param[in] pvlc_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pvlc(struct ku_pvlc_reg      *pvlc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PSPA operations.
 *
 * @param[in] pspa_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pspa(struct ku_pspa_reg      *pspa_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PMLP operations.
 *
 * @param[in] pmlp_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pmlp(struct ku_pmlp_reg      *pmlp_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PLIB operations.
 *
 * @param[in] plib_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_plib(struct ku_plib_reg      *plib_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PPTT operations.
 *
 * @param[in] pptt_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pptt(struct ku_pptt_reg      *pptt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PPRT operations.
 *
 * @param[in] pprt_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pprt(struct ku_pprt_reg      *pprt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);


/**
 *  This function performs access register PPAOS operations.
 *
 * @param[in] ppaos_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ppaos(struct ku_ppaos_reg     *ppaos_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);
/**
 *  This function performs access register PLPC operations.
 *
 * @param[in] plpc_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_plpc(struct ku_plpc_reg      *plpc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PPLM operations.
 *
 * @param[in] pplm_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pplm(struct ku_pplm_reg      *pplm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PMPR operations.
 *
 * @param[in] pmpr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pmpr(struct ku_pmpr_reg      *pmpr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PMCR operations.
 *
 * @param[in] pmcr_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 *
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pmcr(struct ku_pmcr_reg      *pmcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PFSC operations.
 *
 * @param[in] pfsc_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pfsc(struct ku_pfsc_reg      *pfsc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PMMP operations.
 *
 * @param[in] pmmp_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pmmp(struct ku_pmmp_reg      *pmmp_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register QSPTC operations.
 *
 * @param[in] qsptc_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qsptc(struct ku_qsptc_reg     *qsptc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register QSTCT operations.
 *
 * @param[in] qstct_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qstct(struct ku_qstct_reg     *qstct_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);


/**
 *  This function performs access register HTGT operations.
 *
 * @param[in] hopf_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_hopf(struct ku_hopf_reg      *hopf_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);


/**
 *  This function performs access register HTGT operations.
 *
 * @param[in] htgt_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_htgt(struct ku_htgt_reg      *htgt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register HPKT operations.
 *
 * @param[in] hpkt_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_hpkt(struct ku_hpkt_reg      *hpkt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register HCAP operations.
 *
 * @param[in] hcap_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_hcap(struct ku_hcap_reg      *hcap_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register HCTR operations.
 *
 * @param[in] hctr_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_hctr(struct ku_hctr_reg      *hctr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register HDRT operations.
 *
 * @param[in] hdrt_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_hdrt(struct ku_hdrt_reg      *hdrt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PELC operations.
 *
 * @param[in] pelc_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pelc(struct ku_pelc_reg      *pelc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register SPZR operations.
 *
 * @param[in] spzr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_spzr(struct ku_spzr_reg      *spzr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MCIA operations.
 *
 * @param[in] mcia_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mcia(struct ku_mcia_reg      *mcia_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MFBA operations.
 *
 * @param[in] mfba_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mfba(struct ku_mfba_reg      *mfba_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MFBE operations.
 *
 * @param[in] mfbe_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mfbe(struct ku_mfbe_reg      *mfbe_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MFCR operations.
 *
 * @param[in] mfcr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mfcr(struct ku_mfcr_reg      *mfcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MFPA operations.
 *
 * @param[in] mfpa_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mfm(struct ku_mfm_reg       *mfm_reg_data,
                                sxd_reg_meta_t          *reg_meta,
                                uint32_t                 data_num,
                                sxd_completion_handler_t handler,
                                void                    *context);

/**
 *  This function performs access register MGIR operations.
 *
 * @param[in] mgir_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mgir(struct ku_mgir_reg      *mgir_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

sxd_status_t sxd_access_reg_pcnr(struct ku_pcnr_reg      *pcnr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);


sxd_status_t sxd_access_reg_mfpa(struct ku_mfpa_reg      *mfpa_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PCMR operations.
 *
 * @param[in] pcmr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pcmr(struct ku_pcmr_reg      *pcmr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MFSC operations.
 *
 * @param[in] mfsc_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mfsc(struct ku_mfsc_reg      *mfsc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MFSL operations.
 *
 * @param[in] mfsl_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mfsl(struct ku_mfsl_reg      *mfsl_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MFSM operations.
 *
 * @param[in] mfsm_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mfsm(struct ku_mfsm_reg      *mfsm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MTCAP operations.
 *
 * @param[in] mtcap_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mtcap(struct ku_mtcap_reg     *mtcap_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 * This function performs access register MTBR operations.
 *
 * @param[in] mtbr_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * On MAD access if mtbr_reg_data.num_rec > MTBR_MAX_TEMPRATURE_RECORD only the first
 * MTBR_MAX_TEMPRATURE_RECORD will be retrieved and num_rec will be changed respectively
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mtbr(struct ku_mtbr_reg_ext  *mtbr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MTWE operations.
 *
 * @param[in] mtwe_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mtwe(struct ku_mtwe_reg      *mtwe_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register QPRT operations.
 *
 * @param[in] qprt_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qprt(struct ku_qprt_reg      *qprt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register FORE operations.
 *
 * @param[in] fore_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_fore(struct ku_fore_reg      *fore_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RAW operations.
 *
 * @param[in] raw_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_raw(struct ku_raw_reg       *raw_reg_data,
                                sxd_reg_meta_t          *reg_meta,
                                uint32_t                 data_num,
                                uint16_t                 register_id,
                                sxd_completion_handler_t handler,
                                void                    *context);

/**
 *  This function performs access register HESPR operations.
 *
 * @param[in] hespr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_hespr(struct ku_hespr_reg     *hespr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register SPMCR operations.
 *
 * @param[in] spmcr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_spmcr(struct ku_spmcr_reg     *spmcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register PPSC operations.
 *
 * @param[in] ppsc_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ppsc(struct ku_ppsc_reg      *ppsc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PBMC operations.
 *
 * @param[in] pbmc_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pbmc(struct ku_pbmc_reg      *pbmc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PPTB operations.
 *
 * @param[in] pptb_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pptb(struct ku_pptb_reg      *pptb_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PCAP operations.
 *
 * @param[in] pcap_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pcap(struct ku_pcap_reg      *pcap_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PFCC operations.
 *
 * @param[in] pfcc_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pfcc(struct ku_pfcc_reg      *pfcc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);


/**
 *  This function performs access register PFCA operations.
 *
 * @param[in] pfca_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pfca(struct ku_pfca_reg      *pfca_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PFCNT operations.
 *
 * @param[in] pfcnt_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pfcnt(struct ku_pfcnt_reg     *pfcnt_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);


/**
 *  This function performs access register QPDP operations.
 *
 * @param[in] qpdp_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qpdp(struct ku_qpdp_reg      *qpdp_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register QTCT operations.
 *
 * @param[in] qtct_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qtct(struct ku_qtct_reg      *qtct_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register QCAP operations.
 *
 * @param[in] qcap_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qcap(struct ku_qcap_reg      *qcap_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register QPTS operations.
 *
 * @param[in] qpts_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qpts(struct ku_qpts_reg      *qpts_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register QPCR operations.
 *
 * @param[in] qpcr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qpcr(struct ku_qpcr_reg      *qpcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register QPBR operations.
 *
 * @param[in] qpbr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qpbr(struct ku_qpbr_reg      *qpbr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register SFDT operations.
 *
 * @param[in] sfdt_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sfdt(struct ku_sfdt_reg      *sfdt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register SLDR operations.
 *
 * @param[in] sldr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sldr(struct ku_sldr_reg      *sldr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register SLCR operations.
 *
 * @param[in] slcr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_slcr(struct ku_slcr_reg      *slcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

sxd_status_t sxd_access_reg_slcr_v2(struct ku_slcr_v2_reg   *slcr_v2_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context);

/**
 *  This function performs access register SLCOR operations.
 *
 * @param[in] slcor_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_slcor(struct ku_slcor_reg     *slcor_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register SPMS operations.
 *
 * @param[in] spms_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_spms(struct ku_spms_reg      *spms_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register SCAR operations.
 *
 * @param[in] scar_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_scar(struct ku_scar_reg      *scar_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register SPAD operations.
 *
 * @param[in] spad_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_spad(struct ku_spad_reg      *spad_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MJTAG operations.
 *
 * @param[in] mjtag_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mjtag(struct ku_mjtag_reg     *mjtag_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register SSPR operations.
 *
 * @param[in] sspr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sspr(struct ku_sspr_reg      *sspr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register SPVID operations.
 *
 * @param[in] spvid_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_spvid(struct ku_spvid_reg     *spvid_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register SPVM operations.
 *
 * @param[in] spvm_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_spvm(struct ku_spvm_reg      *spvm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register SPVTR operations.
 *
 * @param[in] spvtr_reg_data - The registers data
 * @param[in] reg_meta	     - The registers meta data
 * @param[in] data_num	     - Number of access operations to perform
 * @param[in] handler	     - Handler function for calling when the operation completes
 * @param[in] context	     - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_spvtr(struct ku_spvtr_reg     *spvtr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register SPAFT operations.
 *
 * @param[in] spaft_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_spaft(struct ku_spaft_reg     *spaft_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register SVER operations.
 *
 * @param[in] sver_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sver(struct ku_sver_reg      *sver_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);


/**
 *  This function performs access register SPVC operations.
 *
 * @param[in] spvc_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_spvc(struct ku_spvc_reg      *spvc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);


/**
 *  This function performs access register SFDAT operations.
 *
 * @param[in] sfdat_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sfdat(struct ku_sfdat_reg     *sfdat_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register SFD operations.
 *
 * @param[in] sfd_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sfd(struct ku_sfd_reg       *sfd_reg_data,
                                sxd_reg_meta_t          *reg_meta,
                                uint32_t                 data_num,
                                sxd_completion_handler_t handler,
                                void                    *context);

/**
 *  This function performs access register SFN operations.
 *
 * @param[in] sfn_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sfn(struct ku_sfn_reg       *sfn_reg_data,
                                sxd_reg_meta_t          *reg_meta,
                                uint32_t                 data_num,
                                sxd_completion_handler_t handler,
                                void                    *context);

/**
 *  This function performs access register SPGT operations.
 *
 * @param[in] spgt_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_spgt(struct ku_spgt_reg      *spgt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register SVMLR operations.
 *
 * @param[in] svmlr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_svmlr(struct ku_svmlr_reg     *svmlr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register SPMLR operations.
 *
 * @param[in] spmlr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_spmlr(struct ku_spmlr_reg     *spmlr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register SPVMLR operations.
 *
 * @param[in] spvmlr_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_spvmlr(struct ku_spvmlr_reg    *spvmlr_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context);

/**
 *  This function performs access register SPFSR operations.
 *
 * @param[in] spfsr_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_spfsr(struct ku_spfsr_reg     *spfsr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register SLECR operations.
 *
 * @param[in] slecr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_slecr(struct ku_slecr_reg     *slecr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register SFDF operations.
 *
 * @param[in] sfdf_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sfdf(struct ku_sfdf_reg      *sfdf_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);


/**
 *  This function performs access register SVPE operations.
 *
 * @param[in] svpe_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_svpe(struct ku_svpe_reg      *svpe_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *
 *  This function performs access register SFTR operations.
 *
 * @param[in] sftr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sftr(struct ku_sftr_reg      *sftr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register SMID operations.
 *
 * @param[in] smid_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_smid(struct ku_smid_reg      *smid_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PMAOS operations.
 *
 * @param[in] pmaos_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pmaos(struct ku_pmaos_reg     *pmaos_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register PAGT operations.
 *
 * @param[in] pagt_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pagt(struct ku_pagt_reg      *pagt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PIFR operations.
 *
 * @param[in] pifr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pifr(struct ku_pifr_reg      *pifr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PPBT operations.
 *
 * @param[in] ppbt_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ppbt(struct ku_ppbt_reg      *ppbt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PTCE operations.
 *
 * @param[in] ptce_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ptce(struct ku_ptce_reg      *ptce_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);
/**
 *  This function performs access register PTCE2 operations.
 *
 * @param[in] ptce2_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ptce2(struct ku_ptce2_reg     *ptce2_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register PEMB operations.
 *
 * @param[in] pemb_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pemb(struct ku_pemb_reg      *pemb_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);


/**
 *  This function performs access register PECB operations.
 *
 * @param[in] pecb_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pecb(struct ku_pecb_reg      *pecb_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PRBT operations.
 *
 * @param[in] prbt_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_prbt(struct ku_prbt_reg      *prbt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);


/**
 *  This function performs access register PEFA operations.
 *
 * @param[in] pefa_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pefa(struct ku_pefa_reg      *pefa_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);


/**
 *  This function performs access register PRCR operations.
 *
 * @param[in] prcr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_prcr(struct ku_prcr_reg      *prcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PACL operations.
 *
 * @param[in] pacl_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pacl(struct ku_pacl_reg      *pacl_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PTAR operations.
 *
 * @param[in] ptar_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ptar(struct ku_ptar_reg      *ptar_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PVGT operations.
 *
 * @param[in] pvgt_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pvgt(struct ku_pvgt_reg      *pvgt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PPRR operations.
 *
 * @param[in] pvbt_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pvbt(struct ku_pvbt_reg      *pvbt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PPRR operations.
 *
 * @param[in] pprr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pprr(struct ku_pprr_reg      *pprr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PGCR operations.
 *
 * @param[in] pgcr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pgcr(struct ku_pgcr_reg      *pgcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PUET operations.
 *
 * @param[in] puet_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_puet(struct ku_puet_reg      *puet_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RATR operations.
 *
 * @param[in] ratr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ratr(struct ku_ratr_reg      *ratr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RATRAD operations.
 *
 * @param[in] ratrad_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ratrad(struct ku_ratrad_reg    *ratrad_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context);

/**
 *  This function performs access register RUFT operations.
 *
 * @param[in] ruft_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ruft(struct ku_ruft_reg      *ruft_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RUHT operations.
 *
 * @param[in] ruht_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ruht(struct ku_ruht_reg      *ruht_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RAUHT operations.
 *
 * @param[in] rauht_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rauht(struct ku_rauht_reg     *rauht_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register RAUHTD operations.
 *
 * @param[in] rauhtd_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rauhtd(struct ku_rauhtd_reg    *rauhtd_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context);

/**
 *  This function performs access register RDPM operations.
 *
 * @param[in] rdpm_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rdpm(struct ku_rdpm_reg      *rdpm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RICA operations.
 *
 * @param[in] rica_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rica(struct ku_rica_reg      *rica_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RRCR operations.
 *
 * @param[in] rrcr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rrcr(struct ku_rrcr_reg      *rrcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RICNT operations.
 *
 * @param[in] ricnt_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ricnt(struct ku_ricnt_reg     *ricnt_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register RECR operations.
 *
 * @param[in] recr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_recr(struct ku_recr_reg      *recr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RECRv2 operations.
 *
 * @param[in] recr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_recr_v2(struct ku_recr_v2_reg   *recr_v2_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context);

/**
 *  This function performs access register RTAR operations.
 *
 * @param[in] rtar_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rtar(struct ku_rtar_reg      *rtar_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RITR operations.
 *
 * @param[in] ritr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ritr(struct ku_ritr_reg      *ritr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RALTA operations.
 *
 * @param[in] ralta_reg_data - The registers data
 * @param[in] reg_meta	     - The registers meta data
 * @param[in] data_num	     - Number of access operations to perform
 * @param[in] handler	     - Handler function for calling when the operation completes
 * @param[in] context	     - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ralta(struct ku_ralta_reg     *ralta_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register RALST operations.
 *
 * @param[in] ralst_reg_data - The registers data
 * @param[in] reg_meta	     - The registers meta data
 * @param[in] data_num	     - Number of access operations to perform
 * @param[in] handler	     - Handler function for calling when the operation completes
 * @param[in] context	     - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ralst(struct ku_ralst_reg     *ralst_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register RALTB operations.
 *
 * @param[in] raltb_reg_data - The registers data
 * @param[in] reg_meta	     - The registers meta data
 * @param[in] data_num	     - Number of access operations to perform
 * @param[in] handler	     - Handler function for calling when the operation completes
 * @param[in] context	     - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_raltb(struct ku_raltb_reg     *raltb_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register RALUE operations.
 *
 * @param[in] ralue_reg_data - The registers data
 * @param[in] reg_meta	     - The registers meta data
 * @param[in] data_num	     - Number of access operations to perform
 * @param[in] handler	     - Handler function for calling when the operation completes
 * @param[in] context	     - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ralue(struct ku_ralue_reg     *ralue_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register RALEU operations.
 *
 * @param[in] raleu_reg_data - The registers data
 * @param[in] reg_meta	     - The registers meta data
 * @param[in] data_num	     - Number of access operations to perform
 * @param[in] handler	     - Handler function for calling when the operation completes
 * @param[in] context	     - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_raleu(struct ku_raleu_reg     *raleu_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register RALBU operations.
 *
 * @param[in] ralbu_reg_data - The registers data
 * @param[in] reg_meta	     - The registers meta data
 * @param[in] data_num	     - Number of access operations to perform
 * @param[in] handler	     - Handler function for calling when the operation completes
 * @param[in] context	     - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ralbu(struct ku_ralbu_reg     *ralbu_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register RGCR operations.
 *
 * @param[in] rgcr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rgcr(struct ku_rgcr_reg      *rgcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RTCA operations.
 *
 * @param[in] rtca_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rtca(struct ku_rtca_reg      *rtca_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RTPS operations.
 *
 * @param[in] rtps_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rtps(struct ku_rtps_reg      *rtps_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RMFT operations.
 *
 * @param[in] rmft_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rmft(struct ku_rmft_reg      *rmft_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RMFTv2 operations.
 *
 * @param[in] rmft_v2_reg_data - The registers data
 * @param[in] reg_meta	       - The registers meta data
 * @param[in] data_num	       - Number of access operations to perform
 * @param[in] handler	       - Handler function for calling when the operation completes
 * @param[in] context	       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rmft_v2(struct ku_rmft_v2_reg   *rmft_v2_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context);

/**
 *  This function performs access register RIGR operations.
 *
 * @param[in] rigr_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rigr(struct ku_rigr_reg      *rigr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RIGRv2 operations.
 *
 * @param[in] rigr_v2_reg_data - The registers data
 * @param[in] reg_meta	       - The registers meta data
 * @param[in] data_num	       - Number of access operations to perform
 * @param[in] handler	       - Handler function for calling when the operation completes
 * @param[in] context	       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rigr_v2(struct ku_rigr_v2_reg   *rigr_v2_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context);

/**
 *  This function performs access register RMEIR operations.
 *
 * @param[in] rmeir_reg_data - The registers data
 * @param[in] reg_meta	     - The registers meta data
 * @param[in] data_num	     - Number of access operations to perform
 * @param[in] handler	     - Handler function for calling when the operation completes
 * @param[in] context	     - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rmeir(struct ku_rmeir_reg     *rmeir_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register RMID operations.
 *
 * @param[in] rmid_reg_data - The registers data
 * @param[in] reg_meta	       - The registers meta data
 * @param[in] data_num	       - Number of access operations to perform
 * @param[in] handler	       - Handler function for calling when the operation completes
 * @param[in] context	       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rmid(struct ku_rmid_reg      *rmid_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RMPU operations.
 *
 * @param[in] rmpu_reg_data - The registers data
 * @param[in] reg_meta	       - The registers meta data
 * @param[in] data_num	       - Number of access operations to perform
 * @param[in] handler	       - Handler function for calling when the operation completes
 * @param[in] context	       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rmpu(struct ku_rmpu_reg      *rmpu_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RCAP operations.
 *
 * @param[in] rcap_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rcap(struct ku_rcap_reg      *rcap_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MPAT operations.
 *
 * @param[in] mpat_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mpat(struct ku_mpat_reg      *mpat_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register SBIB operations.
 *
 * @param[in] sbib_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sbib(struct ku_sbib_reg      *sbib_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MPAR operations.
 *
 * @param[in] mpar_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mpar(struct ku_mpar_reg      *mpar_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);
/**
 *  This function performs access register MGPC operations.
 *
 * @param[in] mgpc_reg_data - The registers data
 * @param[in] reg_meta	    - The registers meta data
 * @param[in] data_num	    - Number of access operations to perform
 * @param[in] handler	    - Handler function for calling when the operation completes
 * @param[in] context	    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mgpc(struct ku_mgpc_reg      *mgpc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PLBF operations.
 *
 * @param[in] plbf_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_plbf(struct ku_plbf_reg      *plbf_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MSCI operations.
 *
 * @param[in] msci_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_msci(struct ku_msci_reg      *msci_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MRSR operations.
 *
 * @param[in] mrsr_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mrsr(struct ku_mrsr_reg      *mrsr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 * This function performs access register MPSC operations.
 * @param[in] mpsc_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mpsc(struct ku_mpsc_reg      *mpsc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 * This function performs access register MPRS operations.
 * @param[in] mprs_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mprs(struct ku_mprs_reg      *mprs_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register SGCR operations.
 *
 * @param[in] sgcr_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sgcr(struct ku_sgcr_reg      *sgcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PMPC operations.
 *
 * @param[in] pmpc_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pmpc(struct ku_pmpc_reg      *pmpc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register SBPR operations.
 *
 * @param[in] sbpr_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sbpr(struct ku_sbpr_reg      *sbpr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register SBSR operations.
 *
 * @param[in] sbsr_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sbsr(struct ku_sbsr_reg      *sbsr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register SBCM operations.
 *
 * @param[in] sbcm_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sbcm(struct ku_sbcm_reg      *sbcm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register SBPM operations.
 *
 * @param[in] sbpm_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sbpm(struct ku_sbpm_reg      *sbpm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register SBMM operations.
 *
 * @param[in] sbmm_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sbmm(struct ku_sbmm_reg      *sbmm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register QPDPM operations.
 *
 * @param[in] qpdpm_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qpdpm(struct ku_qpdpm_reg     *qpdpm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register QEPM operations.
 *
 * @param[in] qepm_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qepm(struct ku_qepm_reg      *qepm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register QEEC operations.
 *
 * @param[in] qeec_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qeec(struct ku_qeec_reg      *qeec_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register QPDPC operations.
 *
 * @param[in] qpdpc_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qpdpc(struct ku_qpdpc_reg     *qpdpc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register QTCTM operations.
 *
 * @param[in] qtctm_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qtctm(struct ku_qtctm_reg     *qtctm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register QSPIP operations.
 *
 * @param[in] qspip_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qspip(struct ku_qspip_reg     *qspip_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register QSPCP operations.
 *
 * @param[in] qspcp_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qspcp(struct ku_qspcp_reg     *qspcp_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register QRWE operations.
 *
 * @param[in] qrwe_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qrwe(struct ku_qrwe_reg      *qrwe_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register QPEM operations.
 *
 * @param[in] qpem_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qpem(struct ku_qpem_reg      *qpem_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register QPDSM operations.
 *
 * @param[in] qpdsm_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qpdsm(struct ku_qpdsm_reg     *qpdsm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register QPPM operations.
 *
 * @param[in] qppm_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qppm(struct ku_qppm_reg      *qppm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register CWGCR operations.
 *
 * @param[in] ku_access_cwgcr_reg - The registers data
 * @param[in] reg_meta           - The registers meta data
 * @param[in] data_num           - Number of access operations to perform
 * @param[in] handler            - Handler function for calling when the operation completes
 * @param[in] context                    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_cwgcr(struct ku_cwgcr_reg     *cwgcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register CWCP operations.
 *
 * @param[in] cwtp_reg_data		 - The registers data
 * @param[in] reg_meta           - The registers meta data
 * @param[in] data_num           - Number of access operations to perform
 * @param[in] handler            - Handler function for calling when the operation completes
 * @param[in] context                    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_cwtp(struct ku_cwtp_reg      *cwtp_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register CWCPM operations.
 *
 * @param[in] cwtpm_reg_data	 - The registers data
 * @param[in] reg_meta           - The registers meta data
 * @param[in] data_num           - Number of access operations to perform
 * @param[in] handler            - Handler function for calling when the operation completes
 * @param[in] context                    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_cwtpm(struct ku_cwtpm_reg     *cwtpm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);


/**
 *  This function performs access register CWPP operations.
 *
 * @param[in] cwpp_reg_data		 - The registers data
 * @param[in] reg_meta           - The registers meta data
 * @param[in] data_num           - Number of access operations to perform
 * @param[in] handler            - Handler function for calling when the operation completes
 * @param[in] context                    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_cwpp(struct ku_cwpp_reg      *cwpp_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);


/**
 *  This function performs access register CWPPM operations.
 *
 * @param[in] cwppm_reg_data	 - The registers data
 * @param[in] reg_meta           - The registers meta data
 * @param[in] data_num           - Number of access operations to perform
 * @param[in] handler            - Handler function for calling when the operation completes
 * @param[in] context                    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_cwppm(struct ku_cwppm_reg     *cwppm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register CWPRP operations.
 *
 * @param[in] cpqe_reg_data	 - The registers data
 * @param[in] reg_meta           - The registers meta data
 * @param[in] data_num           - Number of access operations to perform
 * @param[in] handler            - Handler function for calling when the operation completes
 * @param[in] context                    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_cpqe(struct ku_cpqe_reg      *cpqe_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register TNGCR operations.
 *
 * @param[in] tngcr_reg_data     - The registers data
 * @param[in] reg_meta           - The registers meta data
 * @param[in] data_num           - Number of access operations to perform
 * @param[in] handler            - Handler function for calling when the operation completes
 * @param[in] context            - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tngcr(struct ku_tngcr_reg     *tngcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register TIGCR operations.
 *
 * @param[in] tigcr_reg_data	 - The registers data
 * @param[in] reg_meta           - The registers meta data
 * @param[in] data_num           - Number of access operations to perform
 * @param[in] handler            - Handler function for calling when the operation completes
 * @param[in] context            - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tigcr(struct ku_tigcr_reg     *tigcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function set / get  system_m_key
 *
 * @param[in]     access_cmd        - GET / SET
 * @param[in,out] system_m_key_p    - system_m_key struct
 *
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_system_m_key_access(sxd_access_cmd_t        access_cmd,
                                                struct ku_system_m_key *system_m_key_p);

/**
 *  This function performs access register MLCR operations.
 *
 *  @param[in] mlcr_reg_data - The registers data
 *  @param[in] reg_meta      - The registers meta data
 *  @param[in] data_num      - Number of access operations to perform
 *  @param[in] handler       - Handler function for calling when the operation completes
 *  @param[in] context       - The context to give to the handler
 *
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mlcr(struct ku_mlcr_reg      *mlcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MPGCR operations.
 *
 *  @param[in] mpgcr_reg_data - The registers data
 *  @param[in] reg_meta       - The registers meta data
 *  @param[in] data_num       - Number of access operations to perform
 *  @param[in] handler        - Handler function for calling when the operation completes
 *  @param[in] context        - The context to give to the handler
 *
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mpgcr(struct ku_mpgcr_reg     *mpgcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register MPILM operations.
 *
 *  @param[in] mpilm_reg_data - The registers data
 *  @param[in] reg_meta       - The registers meta data
 *  @param[in] data_num       - Number of access operations to perform
 *  @param[in] handler        - Handler function for calling when the operation completes
 *  @param[in] context        - The context to give to the handler
 *
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mpilm(struct ku_mpilm_reg     *mpilm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register MPIBE operations.
 *
 *  @param[in] mpibe_reg_data - The registers data
 *  @param[in] reg_meta       - The registers meta data
 *  @param[in] data_num       - Number of access operations to perform
 *  @param[in] handler        - Handler function for calling when the operation completes
 *  @param[in] context        - The context to give to the handler
 *
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mpibe(struct ku_mpibe_reg     *mpibe_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register MPNHLFE operations.
 *
 *  @param[in] mpnhlfe_reg_data - The registers data
 *  @param[in] reg_meta       - The registers meta data
 *  @param[in] data_num       - Number of access operations to perform
 *  @param[in] handler        - Handler function for calling when the operation completes
 *  @param[in] context        - The context to give to the handler
 *
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mpnhlfe(struct ku_mpnhlfe_reg   *mpnhlfe_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context);
/**
 *  This function performs access register MRRR operations.
 *
 *  @param[in] mrrr_reg_data - The registers data
 *  @param[in] reg_meta      - The registers meta data
 *  @param[in] data_num      - Number of access operations to perform
 *  @param[in] handler       - Handler function for calling when the operation completes
 *  @param[in] context       - The context to give to the handler
 *
 *  @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 *  @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 *  @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mrrr(struct ku_mrrr_reg      *mrrr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MDRI operations.
 *
 *  @param[in] mdri_reg_data - The registers data
 *  @param[in] reg_meta      - The registers meta data
 *  @param[in] data_num      - Number of access operations to perform
 *  @param[in] handler       - Handler function for calling when the operation completes
 *  @param[in] context       - The context to give to the handler
 *
 *  @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 *  @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 *  @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mdri(struct ku_mdri_reg      *mdri_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register HTAC operations.
 *
 *  @param[in] htac_reg_data - The registers data
 *  @param[in] reg_meta      - The registers meta data
 *  @param[in] data_num      - Number of access operations to perform
 *  @param[in] handler       - Handler function for calling when the operation completes
 *  @param[in] context       - The context to give to the handler
 *
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_htac(struct ku_htac_reg      *htac_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register SBDCC operations.
 *
 *  @param[in] sbdcc_reg_data - The registers data
 *  @param[in] reg_meta       - The registers meta data
 *  @param[in] data_num       - Number of access operations to perform
 *  @param[in] handler        - Handler function for calling when the operation completes
 *  @param[in] context        - The context to give to the handler
 *
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sbdcc(struct ku_sbdcc_reg     *sbdcc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register SBDCM operations.
 *
 *  @param[in] sbdcm_reg_data - The registers data
 *  @param[in] reg_meta       - The registers meta data
 *  @param[in] data_num       - Number of access operations to perform
 *  @param[in] handler        - Handler function for calling when the operation completes
 *  @param[in] context        - The context to give to the handler
 *
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sbdcm(struct ku_sbdcm_reg     *sbdcm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);
/**
 *  This function performs access register SBHBR operations.
 *
 *  @param[in] sbhbr_reg_data - The registers data
 *  @param[in] reg_meta       - The registers meta data
 *  @param[in] data_num       - Number of access operations to perform
 *  @param[in] handler        - Handler function for calling when the operation completes
 *  @param[in] context        - The context to give to the handler
 *
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sbhbr(struct ku_sbhbr_reg     *sbhbr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register SBHRR operations.
 *
 *  @param[in] sbhrr_reg_data - The registers data
 *  @param[in] reg_meta       - The registers meta data
 *  @param[in] data_num       - Number of access operations to perform
 *  @param[in] handler        - Handler function for calling when the operation completes
 *  @param[in] context        - The context to give to the handler
 *
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sbhrr(struct ku_sbhrr_reg     *sbhrr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register SBCTC operations.
 *
 *  @param[in] sbctc_reg_data - The registers data
 *  @param[in] reg_meta       - The registers meta data
 *  @param[in] data_num       - Number of access operations to perform
 *  @param[in] handler        - Handler function for calling when the operation completes
 *  @param[in] context        - The context to give to the handler
 *
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sbctc(struct ku_sbctc_reg     *sbctc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register SBCTR operations.
 *
 *  @param[in] sbctr_reg_data - The registers data
 *  @param[in] reg_meta       - The registers meta data
 *  @param[in] data_num       - Number of access operations to perform
 *  @param[in] handler        - Handler function for calling when the operation completes
 *  @param[in] context        - The context to give to the handler
 *
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sbctr(struct ku_sbctr_reg     *sbctr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register SBGCR operations.
 *
 *  @param[in] sbgcr_reg_data - The registers data
 *  @param[in] reg_meta       - The registers meta data
 *  @param[in] data_num       - Number of access operations to perform
 *  @param[in] handler        - Handler function for calling when the operation completes
 *  @param[in] context        - The context to give to the handler
 *
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sbgcr(struct ku_sbgcr_reg     *sbgcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function allow to request port diagnostic information from pddr register.
 *
 *  @param[in] pddr_reg_data  - The registers data
 *  @param[in] reg_meta       - The registers meta data
 *  @param[in] data_num       - Number of access operations to perform
 *  @param[in] handler        - Handler function for calling when the operation completes
 *  @param[in] context        - The context to give to the handler
 *
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pddr(struct ku_pddr_reg      *pddr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register PPBMI operations.
 *
 * @param[in] ppbmi_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ppbmi(struct ku_ppbmi_reg     *ppbmi_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register PPBMP operations.
 *
 * @param[in] ppbmp_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_ppbmp(struct ku_ppbmp_reg     *ppbmp_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register PPBMC operations.
 *
 * @param[in] ppbmc_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ppbmc(struct ku_ppbmc_reg     *ppbmc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register PPBME operations.
 *
 * @param[in] ppbme_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ppbme(struct ku_ppbme_reg     *ppbme_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register PBSR operations.
 *
 *  @param[in] pbsr_reg_data  - The registers data
 *  @param[in] reg_meta       - The registers meta data
 *  @param[in] data_num       - Number of access operations to perform
 *  @param[in] handler        - Handler function for calling when the operation completes
 *  @param[in] context        - The context to give to the handler
 *
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pbsr(struct ku_pbsr_reg      *pbsr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register RMFTAD operations.
 *
 * @param[in] rmftad_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rmftad(struct ku_rmftad_reg    *rmftad_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context);

/**
 * This function performs access register PTCEAD operations.
 *
 * @param[in] ptcead_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 **/
sxd_status_t sxd_access_reg_ptcead(struct ku_ptcead_reg    *ptcead_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context);


/**
 *  This function performs access register QSLL operations.
 *
 * @param[in] qsll_reg_data  - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qsll(struct ku_qsll_reg      *qsll_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);
/**
 *  This function performs access register QHLL operations.
 *
 * @param[in] qhll_reg_data  - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qhll(struct ku_qhll_reg      *qhll_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

/**
 *  This function performs access register MTPPTR operations.
 *
 * @param[in] mtpptr_reg_data  - The registers data
 * @param[in] reg_meta         - The registers meta data
 * @param[in] data_num         - Number of access operations to perform
 * @param[in] handler          - Handler function for calling when the operation completes
 * @param[in] context          - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mtpptr(struct ku_mtpptr_reg    *mtpptr_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context);

/**
 *  This function performs access register PTCE_V3 operations.
 *
 * @param[in] ptce3_reg_data   - The registers data
 * @param[in] reg_meta         - The registers meta data
 * @param[in] data_num         - Number of access operations to perform
 * @param[in] handler          - Handler function for calling when the operation completes
 * @param[in] context          - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ptce3(struct ku_ptce3_reg     *ptce3_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);
/**
 *  This function performs access register PERPT operations.
 *
 * @param[in] perpt_reg_data   - The registers data
 * @param[in] reg_meta         - The registers meta data
 * @param[in] data_num         - Number of access operations to perform
 * @param[in] handler          - Handler function for calling when the operation completes
 * @param[in] context          - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_perpt(struct ku_perpt_reg     *perpt_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register PERAR operations.
 *
 * @param[in] perar_reg_data   - The registers data
 * @param[in] reg_meta         - The registers meta data
 * @param[in] data_num         - Number of access operations to perform
 * @param[in] handler          - Handler function for calling when the operation completes
 * @param[in] context          - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_perar(struct ku_perar_reg     *perar_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);


/**  This function performs access register QPSC operations.
 *
 * @param[in] qpsc_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_qpsc(struct ku_qpsc_reg      *qpsc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);


/**
 *  This function performs access register PERCR operations.
 *
 * @param[in] percr_reg_data   - The registers data
 * @param[in] reg_meta         - The registers meta data
 * @param[in] data_num         - Number of access operations to perform
 * @param[in] handler          - Handler function for calling when the operation completes
 * @param[in] context          - The context to give to the handler
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_percr(struct ku_percr_reg     *percr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);
/**
 *  This function performs access register PEABFE operations.
 *
 * @param[in] peabfe_reg_data   - The registers data
 * @param[in] reg_meta          - The registers meta data
 * @param[in] data_num          - Number of access operations to perform
 * @param[in] handler           - Handler function for calling when the operation completes
 * @param[in] context           - The context to give to the handler
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_peabfe(struct ku_peabfe_reg    *peabfe_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context);
/**
 *  This function performs access register MTPPPC operations.
 *
 * @param[in] mtpppc_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 *  @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mtpppc(struct ku_mtpppc_reg    *mtpppc_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context);

/**
 *  This function performs access register MCION operations.
 *
 * @param[in] mcion_reg_data  - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mcion(struct ku_mcion_reg     *mcion_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context);

/**
 *  This function performs access register PERERP operations.
 *
 * @param[in] pererp_reg_data  - The registers data
 * @param[in] reg_meta         - The registers meta data
 * @param[in] data_num         - Number of access operations to perform
 * @param[in] handler          - Handler function for calling when the operation completes
 * @param[in] context          - The context to give to the handler
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pererp(struct ku_pererp_reg    *pererp_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context);
/**
 *  This function performs access register MONI operations.
 *
 * @param[in] moni_reg_data   - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_moni(struct ku_moni_reg      *moni_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context);

sxd_status_t sxd_access_reg_svfa_kdb_set(sxd_dev_id_t dev_id,
                                         uint8_t      local_port,
                                         uint16_t     vid,
                                         uint8_t      is_mapped_to_fid,
                                         uint16_t     fid);

#endif /* __SXD_ACCESS_REGISTER_H__ */
