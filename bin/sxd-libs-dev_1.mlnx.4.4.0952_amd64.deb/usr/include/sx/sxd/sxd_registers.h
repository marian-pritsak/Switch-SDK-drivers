/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_REGISTERS_H__
#define __SXD_REGISTERS_H__

#include <sx/sxd/auto_registers/reg.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_reg_id_e enumerated type is used to store SwitchX
 * register ID.
 */
typedef enum sxd_reg_id {
    SXD_REG_ID_SGCR_E = 0x2000,
    SXD_REG_ID_SCAR_E = 0x2001,
    SXD_REG_ID_SPAD_E = 0x2002,
    SXD_REG_ID_SMID_E = 0x2007,
    SXD_REG_ID_SSPR_E = 0x2008,
    SXD_REG_ID_SFDAT_E = 0x2009,
    SXD_REG_ID_SFD_E = 0x200A,
    SXD_REG_ID_SFN_E = 0x200B,
    SXD_REG_ID_SPGT_E = 0x200C,
    SXD_REG_ID_SPMS_E = 0x200D,
    SXD_REG_ID_SPVID_E = 0x200E,
    SXD_REG_ID_SPVM_E = 0x200F,
    SXD_REG_ID_SPAFT_E = 0x2010,
    SXD_REG_ID_SFTR_E = 0x2012,
    SXD_REG_ID_SFDF_E = 0x2013,
    SXD_REG_ID_SLDR_E = 0x2014,
    SXD_REG_ID_SLCR_E = 0x2015,
    SXD_REG_ID_SLCOR_E = 0x2016,
    SXD_REG_ID_SLECR_E = 0x2017,
    SXD_REG_ID_SPMLR_E = 0x2018,
    SXD_REG_ID_SVMLR_E = 0x2019,
    SXD_REG_ID_SPMCR_E = 0x201A,
    SXD_REG_ID_SPVTR_E = 0x201D,
    SXD_REG_ID_SVPE_E = 0x201E,
    SXD_REG_ID_SPVMLR_E = 0x2020,
    SXD_REG_ID_SLCR_V2_E = 0x2021,
    SXD_REG_ID_SFDT_E = 0x2022,
    SXD_REG_ID_SPFSR_E = 0x2023,
    SXD_REG_ID_SVER_E = 0x2025,
    SXD_REG_ID_SPVC_E = 0x2026,
    SXD_REG_ID_CWGCR_E = 0x2801,
    SXD_REG_ID_CWTP_E = 0x2802,
    SXD_REG_ID_CWTPM_E = 0x2803,
    SXD_REG_ID_CWPP_E = 0x2804,
    SXD_REG_ID_CWPPM_E = 0x2805,
    SXD_REG_ID_CPQE_E = 0x2806,

    SXD_REG_ID_PGCR_E = 0x3001,
    SXD_REG_ID_PPBT_E = 0x3002,
    SXD_REG_ID_PVBT_E = 0x3003,
    SXD_REG_ID_PACL_E = 0x3004,
    SXD_REG_ID_PAGT_E = 0x3005,
    SXD_REG_ID_PTAR_E = 0x3006,
    SXD_REG_ID_PTCE_E = 0x3007,
    SXD_REG_ID_PPRR_E = 0x3008,
    SXD_REG_ID_PVGT_E = 0x3009,
    SXD_REG_ID_PFCA_E = 0x300A,
    SXD_REG_ID_PFCNT_E = 0x300B,
    SXD_REG_ID_PRCR_E = 0x300D,
    SXD_REG_ID_PUET_E = 0x300E,
    SXD_REG_ID_PEFA_E = 0x300F,
    SXD_REG_ID_PECB_E = 0x3010,
    SXD_REG_ID_PEMB_E = 0x3011,
    SXD_REG_ID_PPBMI_E = 0x3012,
    SXD_REG_ID_PRBT_E = 0x3013,
    SXD_REG_ID_PTCE2_E = 0x3017,
    SXD_REG_ID_PERPT_E = 0x3021,
    SXD_REG_ID_PEABFE_E = 0x3022,
    SXD_REG_ID_PERAR_E = 0x3026,
    SXD_REG_ID_PTCE3_E = 0x3027,
    SXD_REG_ID_PERCR_E = 0x302A,
    SXD_REG_ID_PERERP_E = 0x302B,

    SXD_REG_ID_QCAP_E = 0x4001,
    SXD_REG_ID_QPTS_E = 0x4002,
    SXD_REG_ID_QPCR_E = 0x4004,
    SXD_REG_ID_QPDP_E = 0x4007,
    SXD_REG_ID_QPRT_E = 0x4008,
    SXD_REG_ID_QSPTC_E = 0x4009,
    SXD_REG_ID_QTCT_E = 0x400A,
    SXD_REG_ID_QSTCT_E = 0x400B,
    SXD_REG_ID_QPBR_E = 0x400C,
    SXD_REG_ID_QEEC_E = 0x400D,
    SXD_REG_ID_QSPIP_E = 0x400E,
    SXD_REG_ID_QRWE_E = 0x400F,
    SXD_REG_ID_QPEM_E = 0x4010,
    SXD_REG_ID_QPDSM_E = 0x4011,
    SXD_REG_ID_QPPM_E = 0x4012,
    SXD_REG_ID_QPDPM_E = 0x4013,
    SXD_REG_ID_QEPM_E = 0x4014,
    SXD_REG_ID_QSLL_E = 0x4015,
    SXD_REG_ID_QHLL_E = 0x4016,
    SXD_REG_ID_QPDPC_E = 0x4017,
    SXD_REG_ID_QTCTM_E = 0x401A,
    SXD_REG_ID_QSPCP_E = 0x401E,
    SXD_REG_ID_QPSC_E = 0x401B,

    SXD_REG_ID_PCAP_E = 0x5001,
    SXD_REG_ID_PMLP_E = 0x5002,
    SXD_REG_ID_PMTU_E = 0x5003,
    SXD_REG_ID_PTYS_E = 0x5004,
    SXD_REG_ID_PFCC_E = 0x5007,
    SXD_REG_ID_PUDE_E = 0x5009,
    SXD_REG_ID_PLIB_E = 0x500A,
    SXD_REG_ID_PPTB_E = 0x500B,
    SXD_REG_ID_PBMC_E = 0x500C,
    SXD_REG_ID_PSPA_E = 0x500D,
    SXD_REG_ID_PELC_E = 0x500E,
    SXD_REG_ID_PVLC_E = 0x500F,
    SXD_REG_ID_PPSC_E = 0x5011,
    SXD_REG_ID_PMAOS_E = 0x5012,
    SXD_REG_ID_PMPR_E = 0x5013,
    SXD_REG_ID_PLBF_E = 0x5015,
    SXD_REG_ID_PIFR_E = 0x5016,
    SXD_REG_ID_PPLR_E = 0x5018,
    SXD_REG_ID_PMPC_E = 0x501F,
    SXD_REG_ID_PLPC_E = 0x5022,
    SXD_REG_ID_PPLM_E = 0x5023,
    SXD_REG_ID_PMPE_E = 0x5024,
    SXD_REG_ID_PDDR_E = 0x5031,
    SXD_REG_ID_PPTT_E = 0x5036,
    SXD_REG_ID_PPRT_E = 0x5037,
    SXD_REG_ID_PBSR_E = 0x5038,
    SXD_REG_ID_PPAOS_E = 0x5040,
    SXD_REG_ID_PCMR_E = 0x5041,
    SXD_REG_ID_PFSC_E = 0x5043,
    SXD_REG_ID_PMMP_E = 0x5044,
    SXD_REG_ID_PMCR_E = 0x5045,
    SXD_REG_ID_PCNR_E = 0x5050,
    SXD_REG_ID_PPBMP_E = 0x5051,
    SXD_REG_ID_PPBMC_E = 0x5052,
    SXD_REG_ID_PPBME_E = 0x5053,

    SXD_REG_ID_SPZR_E = 0x6002,

    SXD_REG_ID_HCAP_E = 0x7001,
    SXD_REG_ID_HTGT_E = 0x7002,
    SXD_REG_ID_HPKT_E = 0x7003,
    SXD_REG_ID_HDRT_E = 0x7004,
    SXD_REG_ID_HESPR_E = 0x7005,
    SXD_REG_ID_HOPF_E = 0x7081,
    SXD_REG_ID_HCTR_E = 0x7083,
    SXD_REG_ID_HTAC_E = 0x7085,

    SXD_REG_ID_RCAP_E = 0x8000,
    SXD_REG_ID_RGCR_E = 0x8001,
    SXD_REG_ID_RITR_E = 0x8002,
    SXD_REG_ID_RIGR_E = 0x8003,
    SXD_REG_ID_RTAR_E = 0x8004,
    SXD_REG_ID_RECR_E = 0x8005,
    SXD_REG_ID_RUFT_E = 0x8006,
    SXD_REG_ID_RMFT_E = 0x8007,
    SXD_REG_ID_RATR_E = 0x8008,
    SXD_REG_ID_RDPM_E = 0x8009,
    SXD_REG_ID_RICA_E = 0x800A,
    SXD_REG_ID_RICNT_E = 0x800B,
    SXD_REG_ID_RUHT_E = 0x800C,
    SXD_REG_ID_RTCA_E = 0x800D,
    SXD_REG_ID_RTPS_E = 0x800E,
    SXD_REG_ID_RRCR_E = 0x800F,
    SXD_REG_ID_RALTA_E = 0x8010,
    SXD_REG_ID_RALST_E = 0x8011,
    SXD_REG_ID_RALTB_E = 0x8012,
    SXD_REG_ID_RALUE_E = 0x8013,
    SXD_REG_ID_RAUHT_E = 0x8014,
    SXD_REG_ID_RALEU_E = 0x8015,
    SXD_REG_ID_RALBU_E = 0x8016,
    SXD_REG_ID_RAUHTD_E = 0x8018,
    SXD_REG_ID_RATRAD_E = 0x8022,
    SXD_REG_ID_RIGRV2_E = 0x8023,
    SXD_REG_ID_RECRV2_E = 0x8025,
    SXD_REG_ID_RMFTV2_E = 0x8027,
    SXD_REG_ID_RMFTAD_E = MLXSW_RMFTAD_ID,
    SXD_REG_ID_PTCEAD_E = MLXSW_PTCEAD_ID,
    SXD_REG_ID_RMID_E = 0x8030,
    SXD_REG_ID_RMPU_E = 0x8032,
    SXD_REG_ID_RMEIR_E = 0x8033,
    SXD_REG_ID_FCAP_E = 0x8401,
    SXD_REG_ID_MPGCR_E = 0x8801,
    SXD_REG_ID_MPILM_E = 0x8802,
    SXD_REG_ID_MPIBE_E = 0x8803,
    SXD_REG_ID_MPNHLFE_E = 0x8804,

    SXD_REG_ID_MFCR_E = 0x9001,
    SXD_REG_ID_MFSC_E = 0x9002,
    SXD_REG_ID_MFSM_E = 0x9003,
    SXD_REG_ID_MFSL_E = 0x9004,
    SXD_REG_ID_FORE_E = 0x9007,
    SXD_REG_ID_MCAS_E = 0x9008,
    SXD_REG_ID_MTCAP_E = 0x9009,
    SXD_REG_ID_MTWE_E = 0x900B,
    SXD_REG_ID_MTBR_E = 0x900F,
    SXD_REG_ID_MFPA_E = 0x9010,
    SXD_REG_ID_MFBA_E = 0x9011,
    SXD_REG_ID_MFBE_E = 0x9012,
    SXD_REG_ID_MCIA_E = 0x9014,
    SXD_REG_ID_MMIA_E = 0x9016,
    SXD_REG_ID_MMDIO_E = 0x9017,
    SXD_REG_ID_MPAT_E = 0x901A,
    SXD_REG_ID_MPAR_E = 0x901B,
    SXD_REG_ID_MFM_E = 0x901D,
    SXD_REG_ID_MHSR_E = 0x901E,
    SXD_REG_ID_MJTAG_E = 0x901F,
    SXD_REG_ID_MGIR_E = 0x9020,
    SXD_REG_ID_MRSR_E = 0x9023,
    SXD_REG_ID_MSCI_E = 0x902A,
    SXD_REG_ID_MLCR_E = 0x902B,
    SXD_REG_ID_MCION_E = 0x9052,
    SXD_REG_ID_MPSC_E = 0x9080,
    SXD_REG_ID_MGPC_E = 0x9081,
    SXD_REG_ID_MPRS_E = 0x9083,
    SXD_REG_ID_MDRI_E = 0x9084,
    SXD_REG_ID_MRRR_E = 0x9087,
    SXD_REG_ID_MTPPPC_E = 0x9090,
    SXD_REG_ID_MTPPTR_E = 0x9091,
    SXD_REG_ID_MONI_E = 0x90F4,

    SXD_REG_ID_TNGCR_E = 0xA001,
    SXD_REG_ID_TIGCR_E = 0xA801,

    SXD_REG_ID_SBGCR_E = 0xB000,
    SXD_REG_ID_SBPR_E = 0xB001,
    SXD_REG_ID_SBCM_E = 0xB002,
    SXD_REG_ID_SBPM_E = 0xB003,
    SXD_REG_ID_SBMM_E = 0xB004,
    SXD_REG_ID_SBSR_E = 0xB005,
    SXD_REG_ID_SBIB_E = 0xB006,
    SXD_REG_ID_SBDCC_E = 0xB007,
    SXD_REG_ID_SBDCM_E = 0xB008,
    SXD_REG_ID_SBHBR_E = 0xB00A,
    SXD_REG_ID_SBHRR_E = 0xB00B,
    SXD_REG_ID_SBCTC_E = 0xB00C,
    SXD_REG_ID_SBCTR_E = 0xB00D,
/* Please, do not move this include.
 *  It includes auto generated code with new cases to this enum statement. */
#include <sx/sxd/auto_registers/sxd_registers_auto.h>
    SXD_REG_ID_RAW_E = 0xffff
} sxd_reg_id_e;

#define SXD_MAX_REGISTERS (64 * 1024)

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_REGISTERS_H__ */
