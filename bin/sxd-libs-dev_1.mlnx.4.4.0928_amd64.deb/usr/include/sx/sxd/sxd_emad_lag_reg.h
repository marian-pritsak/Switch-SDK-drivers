/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_LAG_REG_H__
#define __SXD_EMAD_LAG_REG_H__

#include <sx/sxd/sxd_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

#include <complib/cl_packon.h>

/**
 * sxd_emad_sfdt_reg_t structure is used to store SFDT register
 * layout.
 */
typedef struct sxd_emad_sfdt_reg {
    uint16_t reserved1;
    net16_t  fgl_ptr;
    uint8_t  reserved2[3];
    uint8_t  size;
    uint32_t reserved3[2];
    uint8_t  port_member_list[SXD_SFDT_MAX_PORT_NUM];
} PACK_SUFFIX sxd_emad_sfdt_reg_t;

/**
 * sxd_emad_sldr_reg_t structure is used to store SLDR register
 * layout.
 */
typedef struct sxd_emad_sldr_reg {
    uint8_t op;
    uint8_t reserved1;
    net16_t lag_id;
    uint8_t num_ports;
    uint8_t reserved2;
    net16_t dst_lag_fgl_ptr;
    net32_t base_system_ports_fgl_size[0];
} PACK_SUFFIX sxd_emad_sldr_reg_t;

/**
 * sxd_emad_slcr_reg_t structure is used to store SLCR register
 * layout.
 */
typedef struct sxd_emad_slcr_reg {
    uint8_t reserved1[2];
    uint8_t sh;
    uint8_t type;
    net32_t lag_hash;
    net32_t seed;
    net32_t reserved2;
} PACK_SUFFIX sxd_emad_slcr_reg_t;

/**
 * sxd_emad_slcr_v2_reg_t structure is used to store SLCR_V2 register
 * layout.
 */
typedef struct sxd_emad_slcr_v2_reg {
    uint8_t pp;
    uint8_t local_port;
    uint8_t sh;
    uint8_t type;
    net32_t reserved;
    net32_t seed;
    net32_t general_fields;
    net16_t reserved2;
    net16_t outer_header_enables;
    net32_t outer_header_fields_enable[5];
    uint8_t reserved3[6];
    net16_t inner_header_enables;
    net64_t inner_header_fields_enable;
} PACK_SUFFIX sxd_emad_slcr_v2_reg_t;

/**
 * sxd_emad_slcor_reg_t structure is used to store SLCOR register
 * layout.
 */
typedef struct sxd_emad_slcor_reg {
    uint8_t col;
    uint8_t local_port;
    net16_t lag_id;
    uint8_t reserved1[3];
    uint8_t port_index;
    net32_t reserved2[2];
} PACK_SUFFIX sxd_emad_slcor_reg_t;

#include <complib/cl_packoff.h>

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_LAG_REG_H__ */
