/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_SWID_H__
#define __SXD_SWID_H__

#include <complib/cl_types.h>
#include <sx/sxd/sxd_check.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * Switch ID.
 */
typedef uint8_t sxd_swid_t;

/************************************************
 *  Macros
 ***********************************************/

#define SXD_SWID_MIN (0x00)
#define SXD_SWID_MAX (0x07)

#define SXD_SWID_ID_MIN      SXD_SWID_MIN
#define SXD_SWID_ID_MAX      SXD_SWID_MAX
#define SXD_SWID_ID_STACKING 254
#define SXD_SWID_ID_COUNT    SXD_SWID_MAX - SXD_SWID_MIN + 1

#define SXD_SWID_CHECK_RANGE(swid) (SXD_CHECK_MAX(swid, SXD_SWID_MAX) || (swid == SXD_SWID_ID_STACKING))
/*#define SXD_SWID_CHECK_RANGE(SWID)	SXD_CHECK_MAX(SWID, 255)*/

#define SXD_SWID_DEFAULT SXD_SWID_MIN

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_SWID_H__ */
