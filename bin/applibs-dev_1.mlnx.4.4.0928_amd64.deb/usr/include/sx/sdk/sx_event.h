/*
 *  Copyright (C) 2010-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_EVENT_H__
#define __SX_EVENT_H__

#include <sx/sdk/sx_check.h>

#include "sx/sdk/auto_headers/sx_event_auto.h"


/***********************************************
*  Types definition
***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

/**
 * Event generation mode:
 ******************************************************************************
 * 00 - Do not generate.
 * 01 - Generate.
 */

#define FOREACH_EVENT_GENERATE_MODE(F)                                      \
    F(SX_EVENT_GENERATE_MODE_DONT_GENRATE, "Don't Generate")                \
    F(SX_EVENT_GENERATE_MODE_GENRATE, "Generate")                           \
    F(SX_EVENT_GENERATE_MODE_GENRATE_SINGLE, "Generate Single Event")       \
    F(SX_EVENT_GENERATE_MODE_MIN = SX_EVENT_GENERATE_MODE_DONT_GENRATE, "") \
    F(SX_EVENT_GENERATE_MODE_MAX = SX_EVENT_GENERATE_MODE_GENRATE_SINGLE, "")

typedef enum sx_event_generate_mode {
    FOREACH_EVENT_GENERATE_MODE(SX_GENERATE_ENUM)
} sx_event_generate_mode_t;

#define SX_EVENT_GENERATE_MODE_DEFAULT SX_EVENT_GENERATE_MODE_DONT_GENRATE
#define SX_EVENT_GENERATE_MODE_MIN_MAX SX_EVENT_GENERATE_MODE_MIN, SX_EVENT_GENERATE_MODE_MAX
#define SX_EVENT_GENERATE_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_EVENT_GENERATE_MODE_MIN,   \
                   (int)mode,                    \
                   SX_EVENT_GENERATE_MODE_MAX)

#endif  /*      __SX_EVENT_H__  */
