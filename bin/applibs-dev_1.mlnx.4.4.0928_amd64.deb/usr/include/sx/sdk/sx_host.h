/*
 *  Copyright (C) 2010-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_HOST_H__
#define __SX_HOST_H__

#include <sx/sxd/sxdev.h>
#include <sx/sxd/sxd_host.h>
#include <sx/sdk/sx_event_id.h>
#include <sx/sdk/sx_trap_id.h>
#include <sx/sdk/sx_acl.h>

#include "sx/sdk/auto_headers/sx_host_auto.h"


/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

/**
 * SX_TRAP_GROUP_MAX defines the maximal value for a trap group
 */
#define SX_TRAP_GROUP_MAX 63

/**
 * sx_fd_t structure is used to store SwitchX driver file descriptor.
 */
typedef struct sx_fd {
    int        fd; /* File descriptor for the SXD device */
    sxd_handle driver_handle; /**< handle descriptor for SXD device */
    boolean_t  valid;    /**< Indicates if the descriptor is valid */
} sx_fd_t;

typedef struct ku_l2_tunnel_params sx_l2_tunnel_params_t;

typedef enum sx_user_channel_type {
    SX_USER_CHANNEL_TYPE_FD = SX_KU_USER_CHANNEL_TYPE_FD,
    SX_USER_CHANNEL_TYPE_L3_NETDEV = SX_KU_USER_CHANNEL_TYPE_L3_NETDEV,
    SX_USER_CHANNEL_TYPE_LOG_PORT_NETDEV = SX_KU_USER_CHANNEL_TYPE_L2_NETDEV,
    SX_USER_CHANNEL_TYPE_PHY_PORT_NETDEV = SX_KU_USER_CHANNEL_TYPE_PHY_NETDEV,
    SX_USER_CHANNEL_TYPE_L2_TUNNEL = SX_KU_USER_CHANNEL_TYPE_L2_TUNNEL,
    /* Backport legacy support */
    SX_USER_CHANNEL_TYPE_NET = SX_KU_USER_CHANNEL_TYPE_L3_NETDEV,
} sx_user_channel_type_t;

typedef union sx_user_channel_data {
    sx_fd_t               fd;
    sx_l2_tunnel_params_t l2_tunnel_params;
} sx_user_channel_data_t;

typedef struct sx_user_channel {
    sx_user_channel_type_t type;
    sx_user_channel_data_t channel;
} sx_user_channel_t;

typedef enum sx_truncate_mode {
    SX_TRUNCATE_MODE_DISABLE,
    SX_TRUNCATE_MODE_ENABLE
} sx_truncate_mode_t;

typedef enum sx_control_type {
    SX_CONTROL_TYPE_DEFAULT = 0,
    SX_CONTROL_TYPE_DISABLE = 1,
    SX_CONTROL_TYPE_ENABLE = 2,
} sx_control_type_t;

typedef enum sx_trap_id_user_defined_key_type {
    SX_TRAP_ID_USER_DEFINED_KEY_PACKET_TYPE_E = 0,
    SX_TRAP_ID_USER_DEFINED_KEY_PORT_RANGE_E,
    SX_TRAP_ID_USER_DEFINED_KEY_IPV6_ICMP_TYPE_E,
    SX_TRAP_ID_USER_DEFINED_KEY_NVE_DECAP_ETH_TYPE_E,
    SX_TRAP_ID_USER_DEFINED_KEY_ETH_TYPE_E = SX_TRAP_ID_USER_DEFINED_KEY_NVE_DECAP_ETH_TYPE_E,
} sx_trap_id_user_defined_key_type_t;

/**
 * sx_truncate_size_t is used to store the truncate size
 */
typedef uint16_t sx_truncate_size_t;

/**
 * sx_trap_group_t is used to note trap group
 */
typedef uint32_t sx_trap_group_t;
#define SX_TRAP_GROUP_INVALID 0xffff

#define FOREACH_RECEIVE_DEST_PORT(F)                       \
    F(SX_RECEIVE_DEST_PORT_INVALID_E = 0, "Invalid")       \
    F(SX_RECEIVE_DEST_PORT_MULTI_PORT_E, "Multi Port")     \
    F(SX_RECEIVE_DEST_PORT_NETWORK_PORT_E, "Network Port") \
    F(SX_RECEIVE_DEST_PORT_LAG_PORT_E, "LAG Port")

typedef enum sx_receive_dest_port {
    FOREACH_RECEIVE_DEST_PORT(SX_GENERATE_ENUM)
} sx_receive_dest_port_e;

typedef enum sx_packet_timestamp_source {
    SX_PACKET_TIMESTAMP_SOURCE_LINUX_E = 0, /**< The timestamps associated with the received packets will be read from Linux kernel clock*/
    SX_PACKET_TIMESTAMP_SOURCE_HW_UTC_E = 1, /**< The timestamps associated with the received packets will be read from HW UTC clock */
    SX_PACKET_TIMESTAMP_SOURCE_MIN_E = SX_PACKET_TIMESTAMP_SOURCE_LINUX_E,
    SX_PACKET_TIMESTAMP_SOURCE_MAX_E = SX_PACKET_TIMESTAMP_SOURCE_HW_UTC_E,
} sx_packet_timestamp_source_e;

typedef struct sx_packet_mirror_info {
    sx_span_mirror_reason_e mirror_reason;  /**< Mirror reason of the original packet that does mirror_to_cpu */
    sx_mirror_direction_t   original_direction;  /**< Mirror direction Ingress / Egress */
    sx_cos_traffic_class_t  original_packet_tclass;  /**< Egress tclass of the original packet that does mirror_to_cpu,
                                                      *   SX_SPAN_MIRROR_TCLASS_INVALID means invalid value */
    sx_span_mirror_cong_t original_occupancy;    /**< Port tclass buffer occupancy of the original packet that does mirror_to_cpu,
                                                  *   units of 8KB, SX_SPAN_MIRROR_CONG_INVALID means invalid value */
    sx_span_mirror_latency_t original_latency; /**< End-to-end latency of the original packet that does mirror_to_cpu,
                                                *   default unit is 32 nanoseconds, SX_SPAN_MIRROR_LATENCY_INVALID means invalid value */
    sx_trap_group_t original_trap_group;          /**< Valid if the mirror_reason is SX_SPAN_MIRROR_REASON_TRAP_GROUP */
} sx_packet_mirror_info_t;

/**
 * sx_receive_info_t structure is used to store received
 * packet data
 */
typedef struct sx_host_ifc_receive_info {
    sx_trap_id_t     trap_id;    /**< trap ID */
    sx_event_info_t  event_info;    /**< event info */
    sx_port_log_id_t source_log_port;    /**< source logical port */
    boolean_t        is_lag; /**< Is the source logical port member of a lag */
    sx_port_log_id_t source_lag_port;    /**< source lag port when applicable */
    uint32_t         original_packet_size; /**<the original size of packet in bytes,
                                            *  if packet wasn't truncated packet_size=original_packet_size*/
    boolean_t                    has_timestamp; /**< does packet have a time stamp? */
    struct timespec              timestamp; /**< Time stamp of the packet. For HW UTC time stamp: only 8 LSB in tv_sec are valid */
    uint32_t                     acl_user_id; /**< for ACL trap id: user ID from ACL action. SX_ACL_USER_ID_INVALID otherwise */
    sx_receive_dest_port_e       dest_port_type; /**< Destination logical port type */
    sx_port_log_id_t             dest_log_port; /**< Destination logical port. Valid if dest_type is NETWORK or LAG */
    sx_port_log_id_t             dest_lag_port; /**< Destination logical LAG port. Valid if dest_type is LAG */
    sx_packet_timestamp_source_e timestamp_source; /**< The source of the timestamps associated with the received packets,
                                                    * Spectrum supports only Linux kernel clock. */
    sx_packet_mirror_info_t mirror_info; /**< Supported devices: Spectrum2. Valid if trap_id is one of the MIRROR_AGENT traps */
} sx_receive_info_t;

/**
 * sx_packet_info_t structure is used to store received packet data
 * including receive_info
 */
typedef struct sx_packet_info {
    void            * packet_p;
    uint32_t          packet_size;
    sx_receive_info_t receive_info;
} sx_packet_info_t;

/**
 * sx_trap_group_attributes_t structure is used to store the trap groups
 * attributes
 */
typedef struct sx_trap_group_attributes {
    sx_trap_priority_t prio;            /**< Trap Group Priority. Higher values mean higher priority */
    sx_truncate_mode_t truncate_mode;           /**< enable/disable truncate_mode */
    sx_truncate_size_t truncate_size;           /**< truncate_size, valid only of truncate_mode is enabled */
    sx_control_type_t  control_type;           /**< enable/disable control type */
    boolean_t          add_timestamp;           /**< Add timestamp to trapped packet's receive information */
    boolean_t          is_monitor;           /**< flag which indicate to create monitor trap group */
    sx_fd_t            monitor_fd;           /**< monitor file descriptor. Valid if trap group is monitor */
    uint32_t           hw_trap_group;             /**< Hardware trap group. Valid in sx_api_host_ifc_trap_group_get API,
                                                   *   ignored in sx_api_host_ifc_trap_group_set and sx_api_host_ifc_trap_group_ext_set APIs. */
    sx_packet_timestamp_source_e timestamp_source; /**< The source of the timestamps associated with the received packets,
                                                    *   Spectrum supports only Linux kernel clock */
} sx_trap_group_attributes_t;

typedef enum sx_trap_id_user_defined_packet_type {
    SX_TRAP_ID_USER_DEFINED_PACKET_TYPE_UDP_E = 0,
    SX_TRAP_ID_USER_DEFINED_PACKET_TYPE_TCP_E,
    SX_TRAP_ID_USER_DEFINED_PACKET_TYPE_UDP_TCP_E,
} sx_trap_id_user_defined_packet_type_t;

typedef sx_acl_port_range_entry_t sx_host_ifc_port_range_t;

typedef struct sx_host_ifc_icmpv6_type_user_trap_attr {
    uint8_t icmpv6_type;
} sx_host_ifc_icmpv6_type_user_trap_attr_t;

typedef struct sx_host_ifc_nve_decap_et_type_user_trap_attr {
    uint16_t eth_type;
} sx_host_ifc_nve_decap_et_type_user_trap_attr_t;

typedef union sx_trap_id_user_defined_key_data {
    sx_trap_id_user_defined_packet_type_t          packet_type;
    sx_host_ifc_port_range_t                       port_range;
    sx_host_ifc_icmpv6_type_user_trap_attr_t       icmpv6_attr;
    sx_host_ifc_nve_decap_et_type_user_trap_attr_t nve_decap_eth_attr;
} sx_trap_id_user_defined_key_data_t;

typedef struct sx_trap_id_user_defined_key {
    sx_trap_id_user_defined_key_type_t type;
    sx_trap_id_user_defined_key_data_t key;
} sx_trap_id_user_defined_key_t;

/**
 * sx_trap_id_user_defined_attributes_t structure is used to store the trap IDs
 * attributes
 */
typedef struct sx_trap_id_user_defined_attributes {
    sx_trap_id_user_defined_key_t key_list[RM_API_HOST_IFC_USER_DEFINE_KEY_MAX];
    uint32_t                      key_list_cnt;
} sx_trap_id_user_defined_attributes_t;

/**
 * host interface counter types
 */
typedef enum {
    HOST_IFC_COUNTER_TYPE_TRAP_GROUP_E,
    HOST_IFC_COUNTER_TYPE_TRAP_ID_E
} host_ifc_counter_type_e;

typedef enum {
    HOST_IFC_TRAP_TYPE_PACKET,
    HOST_IFC_TRAP_TYPE_EVENT,
    HOST_IFC_TRAP_TYPE_MAX = HOST_IFC_TRAP_TYPE_EVENT
} host_ifc_trap_type_e;

static __attribute__((__used__)) const char* sx_trap_type_str[] = {
    "Packet",
    "Event",
};

#define SX_TRAP_TYPE_STR(index)                        \
    (SX_CHECK_MAX(index, HOST_IFC_TRAP_TYPE_MAX - 1) ? \
     sx_trap_type_str[index] : "UNKNOWN")

typedef struct sx_host_ifc_counters_filter_trap_group {
    sx_trap_group_t trap_group_filter_list[SX_TRAP_GROUP_MAX];
    uint32_t        trap_group_filter_cnt;
} sx_host_ifc_counters_filter_trap_group_t;

typedef struct sx_host_ifc_counters_filter_trap_id {
    sx_trap_id_t trap_id_filter_list[SX_TRAP_ID_MAX];
    uint32_t     trap_id_filter_cnt;
} sx_host_ifc_counters_filter_trap_id_t;

typedef union sx_host_ifc_counters_filter_type {
    sx_host_ifc_counters_filter_trap_group_t trap_group;
    sx_host_ifc_counters_filter_trap_id_t    trap_id;
} sx_host_ifc_counters_filter_type_t;

/**
 * filter of host interface counters
 */
typedef struct sx_host_ifc_counters_filter {
    host_ifc_counter_type_e                counter_type;
    union sx_host_ifc_counters_filter_type u_counter_type;
} sx_host_ifc_counters_filter_t;

/**
 * host interface global counters
 */
typedef struct sx_host_ifc_global_counters {
    uint64_t event_counter;
    uint64_t tocpu_packet;
    uint64_t tocpu_byte;
    uint64_t tocpu_buffer_drop;
    uint64_t fromcpu_data_packet;
    uint64_t fromcpu_data_byte;
    uint64_t fromcpu_control_packet;
    uint64_t fromcpu_control_byte;
} sx_host_ifc_global_counters_t;

/**
 * host interface trap group counters
 */
typedef struct sx_host_ifc_trap_group_counters {
    sx_trap_group_t       trap_group;
    uint64_t              event_counter;
    uint64_t              tocpu_packet;
    uint64_t              tocpu_byte;
    sx_policer_counters_t tocpu_drop_exceed_rate_packet;
} sx_host_ifc_trap_group_counters_t;

typedef struct sx_host_ifc_trap_id_u_trap_type_event {
    uint64_t event_counter;
} sx_host_ifc_trap_id_u_trap_type_event_t;

typedef struct sx_host_ifc_trap_id_u_trap_type_packet {
    uint64_t tocpu_packet;
    uint64_t tocpu_byte;
} sx_host_ifc_trap_id_u_trap_type_packet_t;

typedef union sx_host_ifc_trap_id_u_trap_type {
    sx_host_ifc_trap_id_u_trap_type_event_t  event;
    sx_host_ifc_trap_id_u_trap_type_packet_t packet;
} sx_host_ifc_trap_id_u_trap_type_t;

/**
 * host interface trap id counters
 */
typedef struct sx_host_ifc_trap_id_counters {
    sx_trap_id_t                          trap_id;
    sx_trap_group_t                       trap_group;
    host_ifc_trap_type_e                  trap_type;
    union sx_host_ifc_trap_id_u_trap_type u_trap_type;
} sx_host_ifc_trap_id_counters_t;

/**
 * host interface counters main structure
 */
typedef struct sx_host_ifc_counters {
    sx_host_ifc_global_counters_t     global_counters;
    sx_host_ifc_trap_group_counters_t trap_group_counters[SX_TRAP_GROUP_MAX];
    uint32_t                          trap_group_counters_cnt;
    sx_host_ifc_trap_id_counters_t    trap_id_counters[SX_TRAP_ID_MAX];
    uint32_t                          trap_id_counters_cnt;
} sx_host_ifc_counters_t;

typedef enum sx_host_ifc_register_key_type {
    SX_HOST_IFC_REGISTER_KEY_TYPE_GLOBAL = 0,
    SX_HOST_IFC_REGISTER_KEY_TYPE_PORT,
    SX_HOST_IFC_REGISTER_KEY_TYPE_VLAN,
    SX_HOST_IFC_REGISTER_KEY_TYPE_MAX = SX_HOST_IFC_REGISTER_KEY_TYPE_VLAN,
} sx_host_ifc_register_key_type_t;

typedef enum dbg_host_ifc_trap_id_counters {
    DBG_HOST_IFC_TRAP_ID_COUNTERS_TRAP_NAME_E = 0,
    DBG_HOST_IFC_TRAP_ID_COUNTERS_TRAP_ID_E,
    DBG_HOST_IFC_TRAP_ID_COUNTERS_TRAP_GROUP_E,
    DBG_HOST_IFC_TRAP_ID_COUNTERS_TYPE_E,
    DBG_HOST_IFC_TRAP_ID_COUNTERS_EVENT_E,
    DBG_HOST_IFC_TRAP_ID_COUNTERS_TOCPU_PACKET_E,
    DBG_HOST_IFC_TRAP_ID_COUNTERS_TOCPU_BYTE_E,
    DBG_HOST_IFC_TRAP_ID_COUNTERS_MAX = DBG_HOST_IFC_TRAP_ID_COUNTERS_TOCPU_BYTE_E,
} dbg_host_ifc_trap_id_counters_e;

typedef enum dbg_host_ifc_trap_group_counters {
    DBG_HOST_IFC_TRAP_GROUP_COUNTERS_TRAP_GROUP_E = 0,
    DBG_HOST_IFC_TRAP_GROUP_COUNTERS_EVENT_E,
    DBG_HOST_IFC_TRAP_GROUP_COUNTERS_TOCPU_PACKET_E,
    DBG_HOST_IFC_TRAP_GROUP_COUNTERS_TOCPU_BYTE_E,
    DBG_HOST_IFC_TRAP_GROUP_COUNTERS_POLICER_VIOLATION_COUNTER_E,
    DBG_HOST_IFC_TRAP_GROUP_COUNTERS_MAX = DBG_HOST_IFC_TRAP_GROUP_COUNTERS_POLICER_VIOLATION_COUNTER_E,
} dbg_host_ifc_trap_group_counters_e;

typedef union sx_host_ifc_register_key_value {
    sx_port_log_id_t port_id;
    sx_vlan_id_t     vlan_id;
} sx_host_ifc_register_key_value_t;

typedef struct sx_host_ifc_register_key {
    sx_host_ifc_register_key_type_t  key_type;
    sx_host_ifc_register_key_value_t key_value;
} sx_host_ifc_register_key_t;

typedef sx_host_ifc_register_key_t sx_host_ifc_filter_key_t;

typedef struct sx_host_ifc_channel_filter_get_entry {
    sx_host_ifc_filter_key_t filter_key;
    sx_user_channel_t        user_channel;
} sx_host_ifc_channel_filter_get_entry_t;

typedef struct sx_trap_group_filter {
    /* Reserved for future expansion*/
} sx_trap_group_filter_t;

typedef struct sx_host_ifc_register_get_entry {
    sx_host_ifc_register_key_t register_key;
    sx_user_channel_t          user_channel;
} sx_host_ifc_register_get_entry_t;

typedef enum sx_host_ifc_trap_key_type {
    HOST_IFC_TRAP_KEY_TRAP_ID_E = 0,
    HOST_IFC_TRAP_KEY_MAX_E = HOST_IFC_TRAP_KEY_TRAP_ID_E
} sx_host_ifc_trap_key_type_e;

typedef union sx_host_ifc_trap_key_attr {
    sx_trap_id_t trap_id;
} sx_host_ifc_trap_key_attr_t;

typedef struct sx_host_ifc_trap_key {
    sx_host_ifc_trap_key_type_e     type;
    union sx_host_ifc_trap_key_attr trap_key_attr;
} sx_host_ifc_trap_key_t;

typedef struct sx_host_ifc_trap_id_trap_attr {
    sx_trap_group_t  trap_group;
    sx_trap_action_t trap_action;
} sx_host_ifc_trap_id_trap_attr_t;

typedef union sx_host_ifc_trap_id_attr {
    sx_host_ifc_trap_id_trap_attr_t trap_id_attr;
} sx_host_ifc_trap_id_attr_t;

typedef struct sx_host_ifc_trap_attr {
    union sx_host_ifc_trap_id_attr attr;
} sx_host_ifc_trap_attr_t;

typedef enum sx_host_ifc_trap_group_key_type {
    HOST_IFC_TRAP_GROUP_KEY_GROUP_ID_E = 0,
    HOST_IFC_TRAP_GROUP_KEY_MAX_E = HOST_IFC_TRAP_GROUP_KEY_GROUP_ID_E
} sx_host_ifc_trap_group_key_type_e;

typedef union sx_host_ifc_trap_group_key_attr {
    sx_trap_group_t trap_group_id;
} sx_host_ifc_trap_group_key_attr_t;

typedef struct sx_host_ifc_trap_group_key {
    sx_host_ifc_trap_group_key_type_e     type;
    union sx_host_ifc_trap_group_key_attr group_key_attr;
} sx_host_ifc_trap_group_key_t;

typedef union sx_host_ifc_trap_group_stat_data {
    uint32_t total_cnt;
} sx_host_ifc_trap_group_stat_data_t;

typedef struct sx_host_ifc_trap_group_stat {
    union sx_host_ifc_trap_group_stat_data data;
} sx_host_ifc_trap_group_stat_t;

#endif /* __SX_HOST_H__ */
