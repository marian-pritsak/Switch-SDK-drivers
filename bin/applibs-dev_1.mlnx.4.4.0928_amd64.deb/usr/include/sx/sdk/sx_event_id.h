/*
 *  Copyright (C) 2010-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef SX_EVENT_ID_H_
#define SX_EVENT_ID_H_

#include <sx/sdk/sx_check.h>
#include <sx/sdk/sx_port.h>
#include <sx/sdk/sx_ip.h>
#include <sx/sdk/sx_router.h>
#include <resource_manager/resource_manager.h>
#include <sx/sdk/sx_tele.h>
#include <sx/sxd/sx_bfd_ctrl_cmds.h>
#include <sx/sdk/sx_tunnel_id.h>
#include <sx/sdk/sx_tunnel.h>

#include "sx/sdk/auto_headers/sx_event_id_auto.h"


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/***********************************************
*  Type definition
***********************************************/

/**
 * Maximum number of items in queue threshold crossed event
 */
#define SX_EVENT_QUEUE_THRESHOLD_CROSSED_MAX 16

/**
 * sx_event_pude_t structure is used to store pude event data
 */
typedef struct sx_event_pude {
    sx_port_log_id_t     log_port; /**< logical port */
    sx_port_oper_state_t oper_state; /**< operational state */
    sx_swid_t            swid; /**< swid */
} sx_event_pude_t;

/**
 * sx_event_pmpe_t structure is used to store pmpe event data
 */
typedef struct sx_event_pmpe {
    uint8_t                     list_size;
    sx_port_log_id_t            log_port_list[RM_API_HOST_IFC_LANE_TO_MODULE_NUM_MAX];
    sx_port_module_state_t      module_state; /* module operational state */
    sx_port_module_error_type_t error_type; /* module operational state */
    sx_port_mod_id_t            module_id;
} sx_event_pmpe_t;

/**
 * sx_event_flae_t structure is used to store flae event data
 */
typedef struct sx_event_flae {
} sx_event_flae_t;

/**
 * sx_event_flae_t structure is used to store ferr event data
 */
typedef struct sx_event_ferr {
} sx_event_ferr_t;

/**
 * sx_event_flae_t structure is used to store tmpw event data
 */
typedef struct sx_event_tmpw {
} sx_event_tmpw_t;

/**
 * sx_event_need_to_resolve_arp_t structure is used to store arp
 * resolve event data
 */
typedef struct sx_event_need_to_resolve_arp {
    sx_ip_addr_t          ip_addr;
    sx_router_id_t        vrid;
    boolean_t             fdb_resolution_need;
    sx_router_interface_t rif;
} sx_event_need_to_resolve_arp_t;

/**
 * sx_event_no_need_to_resolve_arp_t structure is used to store
 * arp resolve event data
 */
typedef struct sx_event_no_need_to_resolve_arp {
    sx_ip_addr_t          ip_addr;
    sx_router_id_t        vrid;
    sx_router_interface_t rif;
} sx_event_no_need_to_resolve_arp_t;

typedef struct sx_rm_sdk_table_notification {
    rm_sdk_table_type_e sdk_table_type;
    boolean_t           is_full;
    boolean_t           is_empty;
} sx_rm_sdk_table_notification_t;

typedef struct sx_rm_hw_table_notification {
    rm_hw_table_type_e hw_table_type;
    boolean_t          is_full;
    boolean_t          is_empty;
} sx_rm_hw_table_notification_t;

typedef struct sx_neigh_activity_notify_entry {
    sx_router_interface_t rif;
    sx_ip_addr_t          ip_addr;
} sx_neigh_activity_notify_entry_t;

typedef struct sx_router_neigh_activity_notification {
    uint32_t                         entry_cnt;
    sx_neigh_activity_notify_entry_t notify_entry[SX_ROUTER_ACTIVITY_NOTIFY_CNT_MAX];
} sx_router_neigh_activity_notification_t;

/**
 * sx_event_queue_threshold_crossed_t structure list of keys which changed threshold state
 * (cross up / down) and the corresponding new threshold state.
 */
typedef struct sx_event_queue_threshold_crossed {
    sx_tele_threshold_key_t          key[SX_EVENT_QUEUE_THRESHOLD_CROSSED_MAX];
    sx_tele_threshold_crossed_data_t data[SX_EVENT_QUEUE_THRESHOLD_CROSSED_MAX];
    uint32_t                         cnt;
} sx_event_queue_threshold_crossed_t;

typedef struct sx_event_ber_monitor {
    sx_port_log_id_t                log_port; /**< logical port */
    sx_port_ber_monitor_oper_data_t ber_monitor_data; /**< BER monitor operational data */
} sx_event_ber_monitor_t;

/**
 * BFD section
 */
typedef struct sx_event_bfd_timeout {
    struct bfd_timeout_event timeout_event;
} sx_event_bfd_timeout_t;

/**
 * sx_event_ibfmr_t structure is used to store IB_FMAD_RCV event data
 */
typedef struct sx_event_ibfmr {
    boolean_t attribute_is_valid; /* The attribute_modifier is valid */
    uint16_t  attribute_id;       /* Attribute ID of the received MAD */
    uint32_t  attribute_modifier; /* Attribute modifier of the received MAD */
} sx_event_ibfmr_t;


#define FOREACH_OBJECT_TYPE(F)                                   \
    F(SX_OBJECT_TYPE_VRID = 1, "VRID")                           \
    F(SX_OBJECT_TYPE_RIF = 2, "RIF")                             \
    F(SX_OBJECT_TYPE_ECMP = 3, "ECMP")                           \
    F(SX_OBJECT_TYPE_TUNNEL = 4, "Tunnel")                       \
    F(SX_OBJECT_TYPE_TUNNEL_MAP_OBJECT = 5, "Tunnel map object") \
    F(SX_OBJECT_TYPE_MIN = SX_OBJECT_TYPE_VRID, "")              \
    F(SX_OBJECT_TYPE_MAX = SX_OBJECT_TYPE_TUNNEL_MAP_OBJECT, "")
/**
 * sx_object_type_t is used to distinguish between different SDK objects.
 */
typedef enum sx_object_type {
    FOREACH_OBJECT_TYPE(SX_GENERATE_ENUM)
} sx_object_type_t;

#define SX_OBJECT_TYPE_CHECK_RANGE(OBJECT_TYPE) \
    SX_CHECK_RANGE(SX_OBJECT_TYPE_MIN,          \
                   OBJECT_TYPE,                 \
                   SX_OBJECT_TYPE_MAX)          \

typedef struct sx_tunnel_map_object {
    sx_tunnel_id_t        tunnel_id;
    sx_tunnel_map_entry_t map_entry;
} sx_tunnel_map_object_t;

typedef union sx_event_object_id {
    sx_router_id_t         vrid;        /**< Virtual router ID */
    sx_router_interface_t  rif_id;      /**< Router interface ID */
    sx_ecmp_id_t           ecmp_id;     /**< ECMP container ID */
    sx_tunnel_id_t         tunnel_id;
    sx_tunnel_map_object_t tunnel_map_object;
} sx_event_object_id_t;

/**
 * sx_object_id_t structure is used as an abstract representation for SDK
 * object IDs.
 */
typedef struct sx_object_id {
    sx_object_type_t         object_type;   /**< Object type */
    union sx_event_object_id object_id;
} sx_object_id_t;

#define SX_EVENT_DELETED_OBJECT_CNT_MAX 64
typedef struct sx_event_deleted_object {
    uint32_t       object_cnt;
    sx_object_id_t object[SX_EVENT_DELETED_OBJECT_CNT_MAX];
} sx_event_deleted_object_t;

/**
 * Sent with port added or removed from a LAG event
 */
typedef struct sx_event_port_lag_changes {
    sx_port_log_id_t log_port;
    sx_port_log_id_t lag_port;
} sx_event_port_lag_changes_t;

/**
 * Sent with port created or removed event
 */
typedef struct sx_event_port_added_deleted {
    sx_port_log_id_t log_port;
} sx_event_port_added_deleted_t;


/**
 * sx_event_info_t union is used to store events data
 */
typedef union sx_event_info {
    sx_event_pude_t                            pude; /**< pude event data */
    sx_event_pmpe_t                            pmpe; /**< pmpe event data */
    sx_event_flae_t                            flae; /**< flae event data */
    sx_event_ferr_t                            ferr; /**< ferr event data */
    sx_event_tmpw_t                            tmpw; /**< tmpw event data */
    sx_event_need_to_resolve_arp_t             need_to_resolve_arp;
    sx_event_no_need_to_resolve_arp_t          no_need_to_resolve_arp;
    sx_rm_sdk_table_notification_t             rm_sdk_table_notification;
    sx_rm_hw_table_notification_t              rm_hw_table_notification;
    sx_router_neigh_activity_notification_t    router_neigh_activity_notification;
    sx_router_mc_route_activity_notification_t router_mc_route_activity_notification;
    sx_fdb_mc_ip_addr_activity_notification_t  fdb_mc_ip_addr_activity_notification;
    sx_event_queue_threshold_crossed_t         queue_threshold_crossed;
    sx_event_ber_monitor_t                     ber_monitor;
    sx_event_bfd_timeout_t                     bfd_timeout;
    sx_event_ibfmr_t                           ibfmr; /**< ibfmr event data */
    sx_event_port_lag_changes_t                port_lag_changes;
    sx_event_port_added_deleted_t              port_added_or_deleted;
    sx_event_deleted_object_t                  deleted_object;
} sx_event_info_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* SX_EVENT_ID_H_ */
