/*
 *  Copyright (C) 2010-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef SX_POLICER_H_
#define SX_POLICER_H_

#include <sx/sxd/sxd_policer.h>

#include <sx/sdk/sx_swid.h>

#include "sx/sdk/auto_headers/sx_policer_auto.h"


/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

/**
 * SX_POLICER_ID_INVALID define Invalid Policer ID
 */
#define SX_POLICER_ID_INVALID (0xFFFFFFFF)

typedef uint64_t sx_policer_id_t;

/**
 * Placeholder for Filter to be used with the iterator
 */
typedef uint32_t sx_policer_id_filter_t;

/**
 * Define maximum global policers number
 */
#define SX_POLICER_MAX_POLICERS_GLOBAL 9

/**
 * Define minimum policer CBS
 */
#define SX_POLICER_CBS_MIN (0x10)

/**
 * Define maximum policer CBS
 */
#define SX_POLICER_CBS_MAX (1 << 30)

/**
 * Define minimum policer EBS
 */
#define SX_POLICER_EBS_MIN (1)

/**
 * Define maximum policer EBS
 */
#define SX_POLICER_EBS_MAX (1 << 30)

/**
 * Define minimum policer CIR
 */
#define SX_POLICER_CIR_MIN (1)

/**
 * Define CIR units when metering traffic rate (Mbps)
 */
#define SX_POLICER_CIR_UNIT_TRAFFIC_RATE (5)

/**
 * Define maximum policer CIR (in units) when metering traffic rate
 */
#define SX_POLICER_CIR_MAX_UNITS_TRAFFIC_RATE (0xFFFFFF / SX_POLICER_CIR_UNIT_TRAFFIC_RATE)

/**
 * Define maximum policer CIR (in units) when metering packet rate
 */
#define SX_POLICER_CIR_MAX_UNITS_PACKET_RATE (2566 * 6536)

/**
 * Define CIR units when metering packet rate (fps)
 */
#define SX_POLICER_CIR_UNIT_PACKET_RATE (1)

/*********/
/* ENUMS */
/*********/

#define FOREACH_POLICER_ACTION(F)                                  \
    F(SX_POLICER_ACTION_FORWARD = 0, "Forward")                    \
    F(SX_POLICER_ACTION_DISCARD = 1, "Discard")                    \
    F(SX_POLICER_ACTION_FORWARD_SET_RED_COLOR = 2, "Set Color")    \
    F(SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR = 2, "Set Color") \
    F(SX_POLICER_ACTION_MIN = SX_POLICER_ACTION_FORWARD, "")       \
    F(SX_POLICER_ACTION_MAX = SX_POLICER_ACTION_FORWARD_SET_RED_COLOR, "")
/**
 * sx_policer_action_t enumerated type is used to store
 * policer action.
 */
typedef enum sx_policer_action {
    FOREACH_POLICER_ACTION(SX_GENERATE_ENUM)
} sx_policer_action_t;

#define FOREACH_POLICER_RATE_TYPE(F)                                        \
    F(SX_POLICER_RATE_TYPE_SX_E = 0, "SX") /* for backward compatibility */ \
    F(SX_POLICER_RATE_TYPE_SINGLE_RATE_E = 1, "Single")                     \
    F(SX_POLICER_RATE_TYPE_DUAL_RATE_E, "Dual")                             \
    F(SX_POLICER_RATE_TYPE_MIN = SX_POLICER_RATE_TYPE_SX_E, "")             \
    F(SX_POLICER_RATE_TYPE_MAX = SX_POLICER_RATE_TYPE_DUAL_RATE_E, "")

/**
 * sx_policer_rate_type_e enumerated type is used to store
 * global rate type.
 */
typedef enum sx_policer_rate_type {
    FOREACH_POLICER_RATE_TYPE(SX_GENERATE_ENUM)
} sx_policer_rate_type_e;


#define FOREACH_POLICER_METER(F)                           \
    F(SX_POLICER_METER_PACKETS = 0, "Packets")             \
    F(SX_POLICER_METER_TRAFFIC = 1, "Traffic")             \
    F(SX_POLICER_METER_MIN = SX_POLICER_METER_PACKETS, "") \
    F(SX_POLICER_METER_MAX = SX_POLICER_METER_TRAFFIC, "")
/**
 * sx_policer_meter_t enumerated type is used to store
 * policer operations.
 */
typedef enum sx_policer_meter {
    FOREACH_POLICER_METER(SX_GENERATE_ENUM)
} sx_policer_meter_t;

#define FOREACH_POLICER_IR_UNITS(F)                                     \
    F(SX_POLICER_IR_UNITS_10_POWER_6_E = 0, "10^6")                     \
    F(SX_POLICER_IR_UNITS_10_POWER_3_E = 1, "10^3")                     \
    F(SX_POLICER_IR_UNITS_MIN_E = SX_POLICER_IR_UNITS_10_POWER_6_E, "") \
    F(SX_POLICER_IR_UNITS_MAX_E = SX_POLICER_IR_UNITS_10_POWER_3_E, "")

/**
 * sx_policer_ir_units_e enumerated type is used to store
 * cir & eir units type.
 */
typedef enum sx_policer_ir_units {
    FOREACH_POLICER_IR_UNITS(SX_GENERATE_ENUM)
} sx_policer_ir_units_e;

/**
 * Policer attributes:
 *
 * ir_units (CIR and EIR units) possible values for traffic metering:
 *      10^3 or 10^6. relevant only for traffic metering.
 *
 * CIR possible values for traffic metering:
 *      Unit is ir_units bits/sec (see ir_units field)
 *      Maximum value is 2Tbps (after ir_units calculation)
 *
 * CIR possible values for packet metering:
 *      Unit is 1 packet/sec
 *      Maximum value is 2 Gigs packets per second
 *
 * EIR possible values for traffic metering:
 *      Unit is ir_units bits/sec (see ir_units_field)
 *      Maximum value is 2Tbps (after ir_units calculation)
 *
 * EIR possible values for packet metering:
 *      Unit is 1 packet/sec
 *      Maximum value is 2 Gigs packets per second
 *
 * CBS and EBS possible values for traffic metering:
 *      burst size is (2^CBS)*512 [bits]
 *      range is from CIR*rate*50uSec to 32Gbit while rate is according
 *      to ir_units (10^3/10^6)
 *      Minimum value is 4
 *      Maximum value is 26
 *
 * CBS possible values for packet metering:
 *      burst size is (2^CBS) [packets]
 *      range is from CIR*50uSec to 32Gbit
 *      Minimum value is 4
 *      Maximum value is 26
 *
 * Yellow action:
 *      must be SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR
 *
 * Red actions:
 *      SX_POLICER_ACTION_FORWARD_SET_RED_COLOR or SX_POLICER_ACTION_DISCARD
 *
 * Rate type:
 *      SX_POLICER_RATE_TYPE_SINGLE_RATE_E or SX_POLICER_RATE_TYPE_DUAL_RATE_E.
 *
 * Color aware:
 *      Determines if the policer decisions are made according to the packets' color.
 *
 * Is host interface policer:
 *     Will the policer be bound to a host interface trap group.
 *
 * Is span session policer:
 *     Will the policer be bound to a SPAN session.
 *     Color aware must be FALSE.
 *     Rate type must be SINGLE RATE.
 *     Red action must be DISCARD.
 *     Supported devices: Spectrum2, Spectrum3.
 */
typedef struct sx_policer_attributes {
    sx_policer_meter_t  meter_type; /**< Packets/Bytes. */
    uint32_t            cbs; /**< Committed Burst Size. */
    uint32_t            ebs; /**< Excess Burst Size. */
    uint32_t            cir; /**< Committed Information Rate. */
    sx_policer_action_t yellow_action; /**< Packets that exceed cbs will be handled with this action.
                                        *  must be SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR */
    sx_policer_action_t    red_action; /**< Packets that exceed ebs will be handled with this action. */
    uint32_t               eir; /**< Excess Information Rate. */
    sx_policer_rate_type_e rate_type;   /**< single-rate/dual-rate. */
    boolean_t              color_aware; /**< Is the policer color aware. */
    boolean_t              is_host_ifc_policer; /**< Is the policer a host_ifc policer. */
    sx_policer_ir_units_e  ir_units; /**< CIR and EIR units (10^3 or 10^6) */
    boolean_t              is_span_session_policer; /**< Is the policer a SPAN session policer.
                                                    * Supported device: Spectrum2, Spectrum3 */
} sx_policer_attributes_t;

/**
 * sx_policer_params_t structure is used to store initialization parameters of
 * Policer Library.
 */
typedef struct sx_policer_params {
    uint8_t priority_group_num;      /**< Number of priority groups */
} sx_policer_params_t;

/**
 * sx_policer_counters_clear_t structure is used to store policer counter reset values.
 */
typedef struct sx_policer_counters_clear {
    boolean_t clear_violation_counter; /**< clear violation counter */
} sx_policer_counters_clear_t;

/**
 * sx_policer_counters_t structure is used to store policer counters values.
 */
typedef struct sx_policer_counters {
    uint64_t violation_counter; /**< violation counter */
} sx_policer_counters_t;


#endif /* SX_POLICER_H_ */
