/*
 *  Copyright (C) 2010-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_MSTP_H__
#define __SX_MSTP_H__

#include <sx/sxd/sxd_emad_mstp.h>

#include <sx/sdk/sx_check.h>

#include "sx/sdk/auto_headers/sx_mstp_auto.h"


/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

#define     __USE_MSTP_INST_ID_0__

/**
 * MSTP Instance ID
 */
typedef uint16_t sx_mstp_inst_id_t;

#ifdef      __USE_MSTP_INST_ID_0__
#define SX_MSTP_INST_ID_MIN (0)
#else   /*      __USE_MSTP_INST_ID_0__  */
#define SX_MSTP_INST_ID_MIN (1)
#endif  /*      __USE_MSTP_INST_ID_0__  */
#define SX_MSTP_INST_ID_MAX     (1024)
#define SX_MSTP_INST_ID_INVALID (0xffff)

#ifdef      __USE_MSTP_INST_ID_0__
#define SX_MSTP_INST_ID_CHECK_RANGE(id) (SX_CHECK_MAX(id, SX_MSTP_INST_ID_MAX))
#else   /*      __USE_MSTP_INST_ID_0__  */
#define SX_MSTP_INST_ID_CHECK_RANGE(id) (SX_CHECK_RANGE(SX_MSTP_INST_ID_MIN, id, SX_MSTP_INST_ID_MAX))
#endif  /*      __USE_MSTP_INST_ID_0__  */


#define FOREACH_MSTP_INST_PORT_STATE(F)                                                         \
    F(SX_MSTP_INST_PORT_STATE_INVALID = 0, "N/A")                                               \
    F(SX_MSTP_INST_PORT_STATE_DISCARDING = SXD_EMAD_SPMS_MSTP_STATE_DISCARDING_E, "Discarding") \
    F(SX_MSTP_INST_PORT_STATE_LEARNING = SXD_EMAD_SPMS_MSTP_STATE_LEARNING_E, "Learning")       \
    F(SX_MSTP_INST_PORT_STATE_FORWARDING = SXD_EMAD_SPMS_MSTP_STATE_FORWARDING_E, "Forwarding") \
    F(SX_MSTP_INST_PORT_STATE_MIN = SX_MSTP_INST_PORT_STATE_DISCARDING, "")                     \
    F(SX_MSTP_INST_PORT_STATE_MAX = SX_MSTP_INST_PORT_STATE_FORWARDING, "")

/**
 * MSTP Instance-Port State
 */
typedef enum sx_mstp_inst_port_state {
    FOREACH_MSTP_INST_PORT_STATE(SX_GENERATE_ENUM)
} sx_mstp_inst_port_state_t;

#define SX_MSTP_INST_PORT_STATE_DEFAULT SX_MSTP_INST_PORT_STATE_DISCARDING
#define SX_MSTP_INST_PORT_STATE_MIN_MAX SX_MSTP_INST_PORT_STATE_MIN, SX_MSTP_INST_PORT_STATE_MAX
#define SX_MSTP_INST_PORT_STATE_CHECK_RANGE(state)      \
    (SX_CHECK_RANGE(SX_MSTP_INST_PORT_STATE_MIN, state, \
                    SX_MSTP_INST_PORT_STATE_MAX))

/**
 * MSTP Exclude-Port State
 */

#define FOREACH_MSTP_EXCLUDE_PORT_STATE(F)                                                         \
    F(SX_MSTP_EXCLUDE_PORT_STATE_NORMAL_E = 0, "Normal")                                               \
    F(SX_MSTP_EXCLUDE_PORT_STATE_FORWARDING_E = SX_MSTP_INST_PORT_STATE_FORWARDING, "Forwarding")

typedef enum sx_mstp_iexclude_port_state {
    FOREACH_MSTP_EXCLUDE_PORT_STATE(SX_GENERATE_ENUM)
} sx_mstp_exclude_port_state_t;


#define FOREACH_MSTP_MODE(F)                    \
    F(SX_MSTP_MODE_NONE, "None")                \
    F(SX_MSTP_MODE_MSTP, "MSTP")                \
    F(SX_MSTP_MODE_RSTP, "RSTP")                \
    F(SX_MSTP_MODE_PVRST, "PVRST")              \
    F(SX_MSTP_MODE_MIN = SX_MSTP_MODE_MSTP, "") \
    F(SX_MSTP_MODE_MAX = SX_MSTP_MODE_PVRST, "")
/**
 * MSTP Activation Mode
 */
typedef enum sx_mstp_mode {
    FOREACH_MSTP_MODE(SX_GENERATE_ENUM)
} sx_mstp_mode_t;

#define SX_MSTP_MODE_DEFAULT SX_MSTP_MODE_RSTP
#define SX_MSTP_MODE_MIN_MAX SX_MSTP_MODE_MIN, SX_MSTP_MODE_MAX
#define SX_MSTP_MODE_CHECK_RANGE(mode) (SX_CHECK_RANGE(SX_MSTP_MODE_MIN, mode, SX_MSTP_MODE_MAX))

/**
 * MSTP Instance Info
 */
typedef struct sx_mstp_inst_info {
    sx_mstp_inst_id_t id;
} sx_mstp_inst_info_t;

/**
 * sx_mstp_params_t structure is used to store initialization parameters of
 * MSTP Library.
 */
typedef struct sx_mstp_params {
    sx_mstp_mode_t mode;    /**< MSTP initialization mode (None, MSTP, RSTP)*/
} sx_mstp_params_t;

/**
 * MSTP instance get filter structure
 */
typedef struct sx_mstp_inst_filter {
    /* Placeholder */
    uint32_t reserved;
} sx_mstp_inst_filter_t;

#endif /* __SX_MSTP_H__ */
