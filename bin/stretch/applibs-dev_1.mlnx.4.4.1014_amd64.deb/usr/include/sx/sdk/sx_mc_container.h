/*
 *  Copyright (C) 2010-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_MC_CONTAINER_H__
#define __SX_MC_CONTAINER_H__

#include <sx/sdk/sx_ip.h>
#include <sx/sdk/sx_status.h>
#include <sx/sdk/sx_router.h>
#include <sx/sdk/sx_flow_counter.h>
#include <resource_manager/resource_manager.h>

#include "sx/sdk/auto_headers/sx_mc_container_auto.h"


/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

#define FOREACH_MC_NEXT_HOP_TYPE(F)                                                                      \
    F(SX_MC_NEXT_HOP_TYPE_INVALID = 0, "N/A")                                                            \
    F(SX_MC_NEXT_HOP_TYPE_VIF = 1, "VIF") /**< A router's endpoint such as RIF or tunnel */              \
    F(SX_MC_NEXT_HOP_TYPE_LOG_PORT, "Logical Port") /**< A physical or logical port */                   \
    F(SX_MC_NEXT_HOP_TYPE_ECMP, "ECMP") /**< An ECMP container */                                        \
    F(SX_MC_NEXT_HOP_TYPE_TUNNEL_ENCAP_IP, "Tunnel ENCAP IP") /**< A nexthop for tunnel encapsulation */ \
    F(SX_MC_NEXT_HOP_TYPE_MIN = SX_MC_NEXT_HOP_TYPE_VIF, "")                                             \
    F(SX_MC_NEXT_HOP_TYPE_MAX = SX_MC_NEXT_HOP_TYPE_TUNNEL_ENCAP_IP, "")

/** Defines the type of a multicast next hop */
typedef enum sx_mc_next_hop_type {
    FOREACH_MC_NEXT_HOP_TYPE(SX_GENERATE_ENUM)
} sx_mc_next_hop_type_t;

#define SX_MC_NEXT_HOP_TYPE_NUM (SX_MC_NEXT_HOP_TYPE_MAX + 1)

#define SX_MC_NEXT_HOP_TYPE_CHECK_RANGE(TYPE) \
    (SX_CHECK_RANGE(SX_MC_NEXT_HOP_TYPE_MIN, (TYPE), SX_MC_NEXT_HOP_TYPE_MAX))

typedef union {
    sx_router_vinterface_t     vif;
    sx_port_log_id_t           log_port;
    sx_ecmp_id_t               ecmp_id;
    sx_ip_next_hop_ip_tunnel_t tunnel_ip;
} sx_mc_next_hop_data_t;

/** Defines a multicast next hop which may be used inside a multicast container */
typedef struct sx_mc_next_hop {
    sx_mc_next_hop_type_t type; /**< Type of next hop */
    sx_mc_next_hop_data_t data; /**< Per-type additional identifier(s) for the next hop */
} sx_mc_next_hop_t;

#define FOREACH_MC_CONTAINER_TYPE(F)                            \
    F(SX_MC_NEXT_HOP_TYPE_N_A = 0, "N/A")                       \
    F(SX_MC_CONTAINER_TYPE_ERIF = 1, "ERIF")                    \
    F(SX_MC_CONTAINER_TYPE_NVE_FLOOD, "NVE Flood")              \
    F(SX_MC_CONTAINER_TYPE_BRIDGE_MC, "Bridge MC")              \
    F(SX_MC_CONTAINER_TYPE_PORT, "Port")                        \
    F(SX_MC_CONTAINER_TYPE_MIN = SX_MC_CONTAINER_TYPE_ERIF, "") \
    F(SX_MC_CONTAINER_TYPE_MAX = SX_MC_CONTAINER_TYPE_PORT, "")

/** Defines the type of a multicast container */
typedef enum sx_mc_container_type {
    FOREACH_MC_CONTAINER_TYPE(SX_GENERATE_ENUM)
} sx_mc_container_type_t;

#define SX_MC_CONTAINER_TYPE_CHECK_RANGE(TYPE) \
    (SX_CHECK_RANGE(SX_MC_CONTAINER_TYPE_MIN, (TYPE), SX_MC_CONTAINER_TYPE_MAX))

/** Defines attributes of a multicast container */
typedef struct sx_mc_container_attributes {
    sx_mc_container_type_t type;
    uint32_t               min_mtu; /**< Minimum MTU of all next hops within the container. Used only for ERIF containers. */
    sx_fid_t               fid;     /**< FID used only for BRIDGE_MC and NVE_FLOOD containers*/
} sx_mc_container_attributes_t;

#endif /* __SX_MC_CONTAINER_H__ */
