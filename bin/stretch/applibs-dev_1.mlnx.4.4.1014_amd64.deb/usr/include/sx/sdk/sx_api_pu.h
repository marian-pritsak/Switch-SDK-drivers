/*
 *  Copyright (C) 2014-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_API_PU_H__
#define __SX_API_PU_H__

#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_pu.h>
#include <sx/sdk/sx_strings.h>

/************************************************
 *  API functions
 ***********************************************/

/**
 * This function sets the log verbosity level of the PU MODULE
 * Supported devices: Spectrum2, Spectrum3.
 *
 * @param[in] handle                   - SX-API handle
 * @param[in] verbosity_target         - set verbosity of : API / MODULE / BOTH
 * @param[in] module_verbosity_level   - PU module verbosity level
 * @param[in] api_verbosity_level      - PU API verbosity level
 *
 * @return SX_STATUS_SUCCESS if the operation completes successfully
 * @return SX_STATUS_PARAM_NULL, SX_STATUS_PARAM_ERROR or SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameter is invalid
 *         SX_STATUS_ERROR general error
 */
sx_status_t sx_api_pu_log_verbosity_level_set(const sx_api_handle_t           handle,
                                               const sx_log_verbosity_target_t verbosity_target,
                                               const sx_verbosity_level_t      module_verbosity_level,
                                               const sx_verbosity_level_t      api_verbosity_level);

/**
 * This function gets the log verbosity level of the PU MODULE
 * Supported devices: Spectrum2, Spectrum3.
 *
 * @param[in]  handle                   - SX-API handle
 * @param[in]  verbosity_target         - get verbosity of : API / MODULE / BOTH
 * @param[out] module_verbosity_level_p - PU module verbosity level
 * @param[out] api_verbosity_level_p    - PU API verbosity level
 *
 * @return SX_STATUS_SUCCESS if the operation completes successfully
 * @return SX_STATUS_PARAM_NULL, SX_STATUS_PARAM_ERROR or SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameter is invalid
 * @return SX_STATUS_ERROR general error
 */
sx_status_t sx_api_pu_log_verbosity_level_get(const sx_api_handle_t           handle,
                                               const sx_log_verbosity_target_t verbosity_target,
                                               sx_verbosity_level_t           *module_verbosity_level_p,
                                               sx_verbosity_level_t           *api_verbosity_level_p);

/**
 *  This function is used to create a raw linear entry in the KVD.
 *  CREATE  is used to allocate a new linear entry in the KVD and it returns the allocated index
 *  SET     is used to set raw data taken as input inside allocated index 
 *  DESTORY is used to destroy an existing entry and free the allocated index
 *  Supported devices: Spectrum2, Spectrum3.
 *
 * @param[in] handle - SX-API handle
 * @param[in] cmd - CREATE / SET / DESTROY
 * @param[in] raw_data - KVD entry raw data
 * @param[in,out] kvd_linear_index - Linear pointer where the entry was stored
 *
 * @return SX_STATUS_SUCCESS if the operation completes successfully
 * @return SX_STATUS_ENTRY_NOT_FOUND if requested element is not found in DB
 * @return SX_STATUS_NO_RESOURCES if no resources are available to create the region
 * @return SX_STATUS_CMD_UNSUPPORTED if the supplied command is unsupported
 */
sx_status_t sx_api_pu_kvd_linear_entry_set(const sx_api_handle_t      handle,
                                           const sx_access_cmd_t      cmd,
                                           const sx_pu_kvd_raw_data_t raw_data,
                                           sx_pu_kvd_linear_idx_t     *kvd_linear_index);

#endif /* ifndef __SX_API_PU_H__ */
