/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_SYSTEM_H__
#define __SXD_EMAD_PARSER_SYSTEM_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_system_data.h>
#include <sx/sxd/sxd_emad_system_reg.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sxd_status_t emad_parser_system_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                    IN sx_verbosity_level_t *verbosity_level_p);

sxd_status_t sxd_emad_parse_sgcr(sxd_emad_sgcr_data_t *sgcr_data,
                                 sxd_emad_sgcr_reg_t  *sgcr_reg);

sxd_status_t sxd_emad_deparse_sgcr(sxd_emad_sgcr_data_t *sgcr_data,
                                   sxd_emad_sgcr_reg_t  *sgcr_reg);

sxd_status_t sxd_emad_parse_scar(sxd_emad_scar_data_t *scar_data,
                                 sxd_emad_scar_reg_t  *scar_reg);

sxd_status_t sxd_emad_deparse_scar(sxd_emad_scar_data_t *scar_data,
                                   sxd_emad_scar_reg_t  *scar_reg);

sxd_status_t sxd_emad_parse_spad(sxd_emad_spad_data_t *spad_data,
                                 sxd_emad_spad_reg_t  *spad_reg);

sxd_status_t sxd_emad_deparse_spad(sxd_emad_spad_data_t *spad_data,
                                   sxd_emad_spad_reg_t  *spad_reg);

sxd_status_t sxd_emad_parse_ppsc(sxd_emad_ppsc_data_t *ppsc_data,
                                 sxd_emad_ppsc_reg_t  *ppsc_reg);

sxd_status_t sxd_emad_deparse_ppsc(sxd_emad_ppsc_data_t *ppsc_data,
                                   sxd_emad_ppsc_reg_t  *ppsc_reg);

sxd_status_t sxd_emad_parse_mjtag(sxd_emad_mjtag_data_t *mjtag_data,
                                  sxd_emad_mjtag_reg_t  *mjtag_reg);

sxd_status_t sxd_emad_deparse_mjtag(sxd_emad_mjtag_data_t *mjtag_data,
                                    sxd_emad_mjtag_reg_t  *mjtag_reg);

sxd_status_t sxd_emad_parse_sspr(sxd_emad_sspr_data_t *sspr_data,
                                 sxd_emad_sspr_reg_t  *sspr_reg);

sxd_status_t sxd_emad_deparse_sspr(sxd_emad_sspr_data_t *sspr_data,
                                   sxd_emad_sspr_reg_t  *sspr_reg);

sxd_status_t sxd_emad_parse_mfba(sxd_emad_mfba_data_t *mfba_data,
                                 sxd_emad_mfba_reg_t  *mfba_reg);

sxd_status_t sxd_emad_deparse_mfba(sxd_emad_mfba_data_t *mfba_data,
                                   sxd_emad_mfba_reg_t  *mfba_reg);

sxd_status_t sxd_emad_parse_mfbe(sxd_emad_mfbe_data_t *mfbe_data,
                                 sxd_emad_mfbe_reg_t  *mfbe_reg);

sxd_status_t sxd_emad_deparse_mfbe(sxd_emad_mfbe_data_t *mfbe_data,
                                   sxd_emad_mfbe_reg_t  *mfbe_reg);

sxd_status_t sxd_emad_parse_mfpa(sxd_emad_mfpa_data_t *mfpa_data,
                                 sxd_emad_mfpa_reg_t  *mfpa_reg);

sxd_status_t sxd_emad_deparse_mfpa(sxd_emad_mfpa_data_t *mfpa_data,
                                   sxd_emad_mfpa_reg_t  *mfpa_reg);

sxd_status_t sxd_emad_parse_msci(sxd_emad_msci_data_t *msci_data,
                                 sxd_emad_msci_reg_t  *msci_reg);

sxd_status_t sxd_emad_deparse_msci(sxd_emad_msci_data_t *msci_data,
                                   sxd_emad_msci_reg_t  *msci_reg);

sxd_status_t sxd_emad_parse_mtbr(sxd_emad_mtbr_data_t *mtbr_data,
                                 sxd_emad_mtbr_reg_t  *mtbr_reg);

sxd_status_t sxd_emad_deparse_mtbr(sxd_emad_mtbr_data_t *mtbr_data,
                                   sxd_emad_mtbr_reg_t  *mtbr_reg);

sxd_status_t sxd_emad_parse_raw(sxd_emad_raw_data_t *raw_data,
                                sxd_emad_raw_reg_t  *raw_reg);

sxd_status_t sxd_emad_deparse_raw(sxd_emad_raw_data_t *raw_data,
                                  sxd_emad_raw_reg_t  *raw_reg);

sxd_status_t sxd_emad_parse_mrsr(sxd_emad_mrsr_data_t *mrsr_data,
                                 sxd_emad_mrsr_reg_t  *mrsr_reg);

sxd_status_t sxd_emad_deparse_mrsr(sxd_emad_mrsr_data_t *mrsr_data,
                                   sxd_emad_mrsr_reg_t  *mrsr_reg);

sxd_status_t sxd_emad_parse_mcion(sxd_emad_mcion_data_t *mcion_data,
                                  sxd_emad_mcion_reg_t  *mcion_reg);

sxd_status_t sxd_emad_deparse_mcion(sxd_emad_mcion_data_t *mcion_data,
                                    sxd_emad_mcion_reg_t  *mcion_reg);

#endif /* __SXD_EMAD_PARSER_SYSTEM_H__ */
